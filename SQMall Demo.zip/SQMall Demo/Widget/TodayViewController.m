//
//  TodayViewController.m
//  Widget
//
//  Created by 双泉 朱 on 15/10/15.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TodayViewController.h"
#import <NotificationCenter/NotificationCenter.h>

@interface TodayViewController () <NCWidgetProviding>

@property (nonatomic, weak) IBOutlet UIImageView * imageView;

- (IBAction)button:(UIButton *)sender;

@end

@implementation TodayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}

- (void)initUI
{
    [self setPreferredContentSize:CGSizeMake(CGRectGetWidth(self.view.frame), 200)];
}

- (IBAction)button:(UIButton *)sender
{
    //    self.extensionContext == today hostApp
    
    [self.extensionContext openURL:[NSURL URLWithString:[NSString stringWithFormat:@"SQMall://2"]] completionHandler:^(BOOL success) {
        
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)widgetPerformUpdateWithCompletionHandler:(void (^)(NCUpdateResult))completionHandler {
    // Perform any setup necessary in order to update the view.
    
    // If an error is encountered, use NCUpdateResultFailed
    // If there's no update required, use NCUpdateResultNoData
    // If there's an update, use NCUpdateResultNewData

    completionHandler(NCUpdateResultNewData);
}

@end
