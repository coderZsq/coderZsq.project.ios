//
//  StarView.h
//
//  Code generated using QuartzCode 1.21 on 15/12/30.
//  www.quartzcodeapp.com
//

#import <UIKit/UIKit.h>

@interface StarView : UIView


- (IBAction)startAllAnimations:(id)sender;

@end