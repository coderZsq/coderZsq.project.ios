//
//  DiscoverViewController.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/10.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "DiscoverViewController.h"
#import "CALayer+SQExtension.h"
#import "MeViewController.h"
#import "SQCardSwitchView.h"
#import "HYVerifyPhoneView.h"
#import "SQCardCell.h"
#import "SQCollectionViewScaleFlowLayout.h"
#import "SQCollectionViewCoverFlowLayout.h"
#import "SQCollectionViewLoopLayout.h"
#import "SQCollectionViewStackLayout.h"
#import "SQCollectionViewWaterFlowLayout.h"
#import "SQCollectionViewInfiniteLoopLayout.h"

@interface DiscoverViewController ()<UICollectionViewDataSource ,UICollectionViewDelegate>
@property (nonatomic,strong) SQCardSwitchView * cardSwitchView;
@property (nonatomic,strong) CALayer * layer;
@property (nonatomic,strong) UICollectionView * collectionView;
@property (nonatomic,strong) SQCollectionViewScaleFlowLayout * flowLayout;
@property (nonatomic,strong) SQCollectionViewCoverFlowLayout * rgFlowLayout;
@property (nonatomic,strong) SQCollectionViewLoopLayout      * loopLayout;
@property (nonatomic,strong) SQCollectionViewStackLayout * stackLayout;
@property (nonatomic,strong) UICollectionViewFlowLayout * layout;
@property (nonatomic,strong) SQCollectionViewWaterFlowLayout * waterFlowLayout;
@property (nonatomic,strong) SQCollectionViewInfiniteLoopLayout * infiniteLayout;

@property (nonatomic,strong) NSMutableArray * images;

@end

@implementation DiscoverViewController

- (SQCollectionViewWaterFlowLayout *)waterFlowLayout {
    
    if (!_waterFlowLayout) {
        _waterFlowLayout = [SQCollectionViewWaterFlowLayout new];
    }
    return _waterFlowLayout;
}

- (NSMutableArray *)images {
    
    if (!_images) {
        _images = @[].mutableCopy;
    }
    return _images;
}

- (UICollectionView *)collectionView {
    
    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 100, self.view.width,140) collectionViewLayout:self.infiniteLayout];
        [_collectionView registerClass:[SQCardCell class] forCellWithReuseIdentifier:@"cell"];
        _collectionView.showsHorizontalScrollIndicator = NO;
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = [UIColor lightGrayColor];
    }
    return _collectionView;
}

- (UICollectionViewFlowLayout *)layout {
    
    if (!_layout) {
        _layout = [UICollectionViewFlowLayout new];
    }
    return _layout;
}

- (SQCollectionViewInfiniteLoopLayout *)infiniteLayout {
    
    if (!_infiniteLayout) {
        _infiniteLayout = [SQCollectionViewInfiniteLoopLayout new];
    }
    return _infiniteLayout;
}

- (SQCollectionViewStackLayout *)stackLayout {
    
    if (!_stackLayout) {
        _stackLayout = [SQCollectionViewStackLayout new];
    }
    return _stackLayout;
}

- (SQCollectionViewLoopLayout *)loopLayout {
    
    if (!_loopLayout) {
        _loopLayout = [SQCollectionViewLoopLayout new];
    }
    return _loopLayout;
}

- (SQCollectionViewCoverFlowLayout *)rgFlowLayout {
    
    if (!_rgFlowLayout) {
        _rgFlowLayout = [SQCollectionViewCoverFlowLayout new];
        _rgFlowLayout.itemWidth = 50;
        _rgFlowLayout.maxAngle = 40;
    }
    return _rgFlowLayout;
}

- (SQCollectionViewScaleFlowLayout *)flowLayout {
    
    if (!_flowLayout) {
        _flowLayout = [SQCollectionViewScaleFlowLayout new];
    }
    return _flowLayout;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];

    [self.view.layer setGradientWithColors:@[(__bridge id)[UIColor whiteColor].CGColor,(__bridge id)[UIColor cyanColor].CGColor] startPoint:CGPointMake(0.5, 0) endPoint:CGPointMake(0.5, 1)];
    [self.view addSubview:self.collectionView];
    
    for (int i = 1; i < 20; i++) {
        NSString * str = [NSString stringWithFormat:@"%i",i];
        [self.images addObject:str];
    }
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {

    if ([self.collectionView.collectionViewLayout isKindOfClass:[SQCollectionViewStackLayout class]]) {
        [self.collectionView setCollectionViewLayout:[SQCollectionViewInfiniteLoopLayout new] animated:YES];
    } else {
        [self.collectionView setCollectionViewLayout:[SQCollectionViewStackLayout new] animated:YES];
    }
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.images.count;
}

//- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
//
//    [self.images removeObjectAtIndex:indexPath.item];
//    [collectionView deleteItemsAtIndexPaths:@[indexPath]];
//}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    SQCardCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    cell.contentView.layer.contents = (__bridge id)[UIImage imageNamed:self.images[indexPath.item]].CGImage;
    return cell;
}























































































//- (SQCardSwitchView *)cardSwitchView {
//    
//    if (!_cardSwitchView) {
//        _cardSwitchView = [SQCardSwitchView new];
//        _cardSwitchView.cards = @[@"1",@"2",@"3",@"4",@"1",@"2",@"3",@"4",@"1",@"2",@"3",@"4",@"1",@"2",@"3",@"4"];
//        _cardSwitchView.pagingEnabled = YES;
//        _cardSwitchView.frame = CGRectMake(0, 100, 320,300);
//    }
//    return _cardSwitchView;
//}


@end
