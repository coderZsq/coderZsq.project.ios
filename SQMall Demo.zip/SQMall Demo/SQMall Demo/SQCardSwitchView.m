//
//  SQCardSwitchView.m
//
//  Created by Doubles_Z on 15/9/5.
//  Copyright (c) 2015年 Doubles_Z. All rights reserved.
//

#import "SQCardSwitchView.h"
#import "SQCard.h"

@interface SQCardSwitchView ()<UIScrollViewDelegate>

@property (nonatomic,strong) UIScrollView   * scrollView;
@property (nonatomic,strong) NSMutableArray * cardArrM;
@property (nonatomic,assign,getter = isFirstEnter) BOOL firstEnter;

@end

@implementation SQCardSwitchView

- (NSMutableArray *)cardArrM {
    
    if (!_cardArrM) {
        _cardArrM = @[].mutableCopy;
    }
    return _cardArrM;
}

- (UIScrollView *)scrollView {
    
    if (!_scrollView) {
        _scrollView = [UIScrollView new];
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.clipsToBounds = NO;
        _scrollView.delegate = self;
    }
    return _scrollView;
}

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        [self setFirstEnter:YES];
        [self initializeSubviews];
    }
    return self;
}

- (void)initializeSubviews {
    [self addSubview:self.scrollView];
}

- (void)setCards:(NSArray *)cards {

    _cards = cards;
    for (int i = 0; i < cards.count; i++) {
        SQCard * card = [SQCard new];
        if ([[cards firstObject] isKindOfClass:[NSString class]]) {
            card.contentView.layer.contents = (__bridge id)[UIImage imageNamed:cards[i]].CGImage;
        } else {
            // costom view parameters
        }
        [self.scrollView addSubview:card];
        [self.cardArrM addObject:card];
    }
}

- (void)setPagingEnabled:(BOOL)pagingEnabled {
    _pagingEnabled = pagingEnabled;
    [self.scrollView setPagingEnabled:pagingEnabled];
}

- (void)layoutSubviews {
    [super layoutSubviews];

    CGFloat cardY = 0;
    CGFloat cardH = self.height;
    CGFloat cardW = cardH / 1.5f;
    [self.cardArrM enumerateObjectsUsingBlock:^(UIView * contentView, NSUInteger idx, BOOL * _Nonnull stop) {
        CGFloat cardX = cardW * idx;
        contentView.frame = CGRectMake(cardX, cardY, cardW, cardH);
    }];
    
    CGFloat scrollViewX = self.pagingEnabled ? (self.width - cardW) * 0.5f : 0;
    CGFloat scrollViewY = 0;
    CGFloat scrollViewW = self.pagingEnabled ? cardW : self.width;
    CGFloat scrollViewH = self.height;
    self.scrollView.frame = CGRectMake(scrollViewX, scrollViewY, scrollViewW, scrollViewH);
    self.scrollView.contentSize   = CGSizeMake(((cardW) * self.cardArrM.count), 0);
    self.scrollView.contentOffset = self.pagingEnabled ? CGPointZero : CGPointMake(-(self.width - cardW) * 0.5f, 0);
    self.scrollView.contentInset  = self.pagingEnabled ? UIEdgeInsetsMake(0, 0, 0, 0) : UIEdgeInsetsMake(0, (self.width-cardW) * 0.5f, 0, (self.width - cardW) * 0.5f);
    [self scrollViewDidScroll:self.scrollView];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    CGFloat pathW = [(UIView *)[self.cardArrM firstObject] width];
    CGFloat pathH = [UIScreen mainScreen].bounds.size.height;
    CGFloat pathX = self.width * 0.5f - pathW;
    CGFloat pathY = self.height * 0.5f - pathH * 0.5f;
    UIBezierPath * path = [UIBezierPath bezierPathWithRect:CGRectMake(pathX, pathY, pathW, pathH)];
    __weak typeof(self) _self = self;
    [self.cardArrM enumerateObjectsUsingBlock:^(SQCard * card, NSUInteger idx, BOOL * _Nonnull stop) {
        CGPoint point = [scrollView convertPoint:card.frame.origin toView:[UIApplication sharedApplication].keyWindow];
        [path containsPoint:point] ? [_self animationWithView:card ratio:1] : [_self animationWithView:card ratio:0.7f];
    }];
}

- (void)animationWithView:(SQCard *)view ratio:(CGFloat)ratio {

    float duration = self.isFirstEnter ? 0 : 0.25f;
    [UIView animateWithDuration:duration animations:^{
        view.contentView.transform = CGAffineTransformMakeScale(ratio, ratio);
    } completion:^(BOOL finished) {
        self.firstEnter = NO;
    }];
}

@end
