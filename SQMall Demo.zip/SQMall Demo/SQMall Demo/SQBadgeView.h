//
//  SQBadgeView.h
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/12/1.
//  Copyright © 2015年 Castiel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQBadgeView : UIButton

@property (nonatomic,copy) NSString * badgeValue;

@end
