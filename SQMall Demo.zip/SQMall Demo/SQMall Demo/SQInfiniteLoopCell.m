//
//  SQInfiniteLoopCell.m
//
//  Created by Doubles_Z on 15/9/5.
//  Copyright (c) 2015年 Doubles_Z. All rights reserved.
//

#import "SQInfiniteLoopCell.h"
#import "SQViewControllerManager.h"
#import "SQTableViewController.h"
#import "SQPageControl.h"

@interface SQInfiniteLoopCell () <UIScrollViewDelegate>

@property (strong, nonatomic) NSMutableArray * infiniteLoopArr;
@property (strong, nonatomic) NSTimer        * timer;

@property (strong, nonatomic) UIScrollView   * scrollView;
@property (strong, nonatomic) SQPageControl  * pageControl;
@property (strong, nonatomic) UIButton       * firstPage;
@property (strong, nonatomic) UIButton       * lastPage;

@property (weak,nonatomic) UIButton * btn;
@property (weak,nonatomic) UIButton * btn2;
@property (weak,nonatomic) UIButton * btn3;
@end

@implementation SQInfiniteLoopCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([SQInfiniteLoopCell class]);
    SQInfiniteLoopCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[SQInfiniteLoopCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

- (NSMutableArray *)infiniteLoopArr {
    
    if (!_infiniteLoopArr) {
        _infiniteLoopArr = @[].mutableCopy;
    }
    return _infiniteLoopArr;
}

- (NSTimeInterval)timeInterval {
    
    if (!_timeInterval) {
        _timeInterval = 2.5f;
    }
    return _timeInterval;
}

- (void)initializeSubviews {
    [self.contentView addSubview:self.scrollView];
    [self.contentView addSubview:self.pageControl];
}

- (UIScrollView *)scrollView {
    
    if (!_scrollView) {
        _scrollView = [UIScrollView new];
        _scrollView.delegate = self;
        _scrollView.bounces = NO;
        _scrollView.pagingEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator = NO;
        for (int i = 0; i < 20; i++) {
            UIButton * content = [UIButton buttonWithType:UIButtonTypeCustom];
            content.adjustsImageWhenHighlighted = NO; content.tag = i;
            if ([content isKindOfClass:[UIButton class]]) {
                [_scrollView addSubview:content];
                [self.infiniteLoopArr addObject:content];
            }
            if ([self respondsToSelector:@selector(touchUpInsideEvents:)]) {
                [content addTarget:self action:@selector(touchUpInsideEvents:) forControlEvents:UIControlEventTouchUpInside];
            }
        }
        [_scrollView addSubview:self.firstPage];
        [_scrollView addSubview:self.lastPage];
    }
    return _scrollView;
}

- (UIButton *)firstPage {
    
    if (!_firstPage) {
        _firstPage = [UIButton buttonWithType:UIButtonTypeCustom];
        _firstPage.adjustsImageWhenHighlighted = NO;
    }
    return _firstPage;
}

- (UIButton *)lastPage {
    
    if (!_lastPage) {
        _lastPage = [UIButton buttonWithType:UIButtonTypeCustom];
        _lastPage.adjustsImageWhenHighlighted = NO;
    }
    return _lastPage;
}

- (SQPageControl *)pageControl {
    
    if (!_pageControl) {
        _pageControl = [SQPageControl new];
        _pageControl.userInteractionEnabled = NO;
        _pageControl.pageIndicatorTintImage        = [UIImage imageNamed:@"new_feature_pagecontrol_point"];
        _pageControl.currentPageIndicatorTintImage = [UIImage imageNamed:@"new_feature_pagecontrol_checked_point"];
    }
    return _pageControl;
}

- (void)setInfiniteLoopData:(NSArray *)infiniteLoopData {
    
    _infiniteLoopData = infiniteLoopData;
    
    [self.timer invalidate];
    [self.firstPage setBackgroundImage:[UIImage imageNamed:[infiniteLoopData firstObject]] forState:UIControlStateNormal];
    [self.lastPage  setBackgroundImage:[UIImage imageNamed:[infiniteLoopData lastObject ]] forState:UIControlStateNormal];
    [infiniteLoopData enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        [self.infiniteLoopArr[idx] setBackgroundImage:[UIImage imageNamed:infiniteLoopData[idx]] forState:UIControlStateNormal];
    }];
    [self setupTimer];
}

- (void)layoutSubviews {
    
    [super layoutSubviews];
  
    CGFloat scrollViewX = 0;
    CGFloat scrollViewY = 0;
    CGFloat scrollViewW = self.contentView.frame.size.width;
    CGFloat scrollViewH = self.contentView.frame.size.height;
    self.scrollView.frame = CGRectMake(scrollViewX, scrollViewY, scrollViewW, scrollViewH);
    self.scrollView.contentSize = CGSizeMake(scrollViewW * (self.infiniteLoopData.count + 2), scrollViewH);

    CGFloat pageControlX = 0;
    CGFloat pageControlH = 37;
    CGFloat pageControlY = scrollViewH - pageControlH + 8;
    CGFloat pageControlW = scrollViewW;
    self.pageControl.frame = CGRectMake(pageControlX, pageControlY, pageControlW, pageControlH);
    self.pageControl.numberOfPages                 = self.infiniteLoopData.count;
    [self layoutScrollView];
}

- (void)layoutScrollView {
    
    CGFloat firstBannerButtonX = (self.infiniteLoopData.count + 1) * self.contentView.frame.size.width;
    CGFloat firstBannerButtonY = 0;
    CGFloat firstBannerButtonW = self.contentView.frame.size.width;
    CGFloat firstBannerButtonH = self.contentView.frame.size.height;
    self.firstPage.frame = CGRectMake(firstBannerButtonX, firstBannerButtonY, firstBannerButtonW, firstBannerButtonH);
    
    CGFloat lastBannerButtonX = 0;
    CGFloat lastBannerButtonY = 0;
    CGFloat lastBannerButtonW = firstBannerButtonW;
    CGFloat lastBannerButtonH = firstBannerButtonH;
    self.lastPage.frame = CGRectMake(lastBannerButtonX, lastBannerButtonY, lastBannerButtonW, lastBannerButtonH);
    
    CGFloat bannerY = 0;
    CGFloat bannerW = firstBannerButtonW;
    CGFloat bannerH = firstBannerButtonH;
    [self.infiniteLoopData enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        CGFloat bannerX = firstBannerButtonW * (idx + 1);
        [self.infiniteLoopArr[idx] setFrame:CGRectMake(bannerX, bannerY, bannerW, bannerH)];
    }];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    self.pageControl.currentPage = (scrollView.contentOffset.x + self.contentView.frame.size.width * 0.5f) / self.contentView.frame.size.width - 1;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [self.timer invalidate];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    [self setupTimer];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
    NSInteger page = (scrollView.contentOffset.x) / self.contentView.frame.size.width;
    if (!page) {
        self.scrollView.contentOffset = CGPointMake(self.contentView.frame.size.width * self.infiniteLoopData.count, 0);
        self.pageControl.currentPage = self.infiniteLoopData.count - 1;
    }
    else if (page == self.infiniteLoopData.count + 1) [self returnSettings];
    else self.pageControl.currentPage = page - 1;
}

- (void)setupTimer {
    if ([self respondsToSelector:@selector(updateTimer)]) {
        self.timer = [NSTimer timerWithTimeInterval:self.timeInterval target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
}

- (void)updateTimer {
    
    NSInteger page = self.pageControl.currentPage + 1;
    [UIView animateWithDuration:0.25f animations:^{
        self.scrollView.contentOffset = CGPointMake(self.contentView.frame.size.width * (page + 1), 0);
    }];
    if (page == self.infiniteLoopData.count) [self returnSettings];
    else  self.pageControl.currentPage = page;
}

- (void)returnSettings {
    self.scrollView.contentOffset = CGPointMake(self.contentView.frame.size.width, 0);
    self.pageControl.currentPage = 0;
}

- (void)touchUpInsideEvents:(UIButton *)sender {
    
    UIButton * btn3 = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn3 setBackgroundImage:[UIImage imageCaptureWithView:[UIApplication sharedApplication].delegate.window] forState:0];
    [btn3 addTarget:self action:@selector(click) forControlEvents:64];
    btn3.adjustsImageWhenHighlighted = NO;
    btn3.frame = kScreenBounds;
    _btn3 = btn3;
    
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.backgroundColor = [UIColor blackColor];
    [btn addTarget:self action:@selector(click) forControlEvents:64];
    btn.frame = kScreenBounds;
    [[SQViewControllerManager shareInstance].currentViewController.tabBarController.view addSubview:btn];
    [btn addSubview:btn3];
    _btn = btn;
    
    UIButton * btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn2.backgroundColor = [UIColor grayColor];
    btn2.frame = CGRectMake(0, kScreenHeight, kScreenWidth, kScreenHeight - 300);
    [[UIApplication sharedApplication].keyWindow addSubview:btn2];
    _btn2 = btn2;
    
    CATransform3D  catrans = CATransform3DIdentity;
    catrans.m34 = -1.0/200;

    [UIView animateWithDuration:0.4 animations:^{
        CGRect frame = btn2.frame;
        frame.origin.y = 300;
        btn2.frame = frame;
        btn3.layer.transform = CATransform3DRotate(catrans, 0.1, .7, 0, 0);
    }];

}

- (void)click {

    CATransform3D  catrans = CATransform3DIdentity;
    catrans.m34 = 0;

    [UIView animateWithDuration:0.4 animations:^{
        _btn3.layer.transform = CATransform3DRotate(catrans, 0, 0, 0, 0);
        CGRect frame = _btn2.frame;
        frame.origin.y = kScreenHeight;
        _btn2.frame = frame;
    } completion:^(BOOL finished) {
        [_btn removeFromSuperview];
        [_btn2 removeFromSuperview];
        [_btn3 removeFromSuperview];
    }];
}

@end
