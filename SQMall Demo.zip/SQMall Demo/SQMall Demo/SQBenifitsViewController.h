//
//  SQBenifitsViewController.h
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/12/28.
//  Copyright © 2015年 Castiel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQBenifitsViewController : UIViewController

@end
