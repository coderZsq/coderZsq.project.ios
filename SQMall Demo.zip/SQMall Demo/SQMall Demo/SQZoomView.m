//
//  SQZoomView.m
//
//  Created by Doubles_Z on 15/9/5.
//  Copyright (c) 2015年 Doubles_Z. All rights reserved.
//

#import "SQZoomView.h"

@interface SQZoomView ()

@property (nonatomic,strong) UIImageView * imageView;

@end

@implementation SQZoomView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

- (UIImageView *)imageView {
    
    if (!_imageView) {
        _imageView = [UIImageView new];
        _imageView.userInteractionEnabled = YES;
    }
    return _imageView;
}

- (void)initializeSubviews {
    [self addSubview:self.imageView];
    // costom view in here
}

- (void)setImage:(UIImage *)image {
    self.imageView.image = _image = image;
}

- (void)setHeight:(CGFloat)height {
    _height = height < 200.0f ? 200.0f : height;
    [self setAttachView:self.attachView];
}

- (void)setAttachView:(UIScrollView *)attachView {
    _attachView = attachView;
    attachView.backgroundColor = [UIColor clearColor];
    attachView.contentInset    = UIEdgeInsetsMake(self.height, 0, 44, 0);
    self.imageView.frame = self.frame = CGRectMake(0, 0, attachView.width, self.height);
}

- (void)layoutSubviews {
    [super layoutSubviews];
}

- (void)zoomWithScrollView:(UIScrollView *)scrollView {
    
    CGFloat offset = -(scrollView.contentOffset.y + self.height);
    CGFloat scale = 1 + 0.01f * offset;
    if (offset > 0) {
        self.imageView.transform = CGAffineTransformMakeScale(scale, scale);
    } else {
        self.imageView.transform = CGAffineTransformMakeTranslation(0, offset);
    }
}

@end
