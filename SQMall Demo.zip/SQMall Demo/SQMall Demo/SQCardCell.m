//
//  SQCardCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/12/28.
//  Copyright © 2015年 Castiel. All rights reserved.
//

#import "SQCardCell.h"

@interface SQCardCell ()

@end

@implementation SQCardCell

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

- (void)initializeSubviews {
    self.contentView.backgroundColor = [UIColor colorWithRed:(arc4random()%255)/255.0 green:(arc4random()%255)/255.0 blue:(arc4random()%255)/255.0 alpha:1];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
}

@end
