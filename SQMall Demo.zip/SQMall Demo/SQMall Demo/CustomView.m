//
//  CustomView.m
//
//  Code generated using QuartzCode 1.21 on 15/12/30.
//  www.quartzcodeapp.com
//

#import "CustomView.h"
#import "QCMethod.h"


@interface CustomView ()

@property (nonatomic, strong) CAShapeLayer *star;
@property (nonatomic, strong) CAShapeLayer *rectangle;

@end

@implementation CustomView

- (instancetype)initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	if (self) {
		[self setupLayers];
	}
	return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
	self = [super initWithCoder:coder];
	if (self) {
		[self setupLayers];
	}
	return self;
}


- (void)setupLayers{
	CAShapeLayer * star = [CAShapeLayer layer];
	star.frame                     = CGRectMake(8.19, 10.03, 14.96, 14.41);
	star.fillColor                 = nil;
	star.strokeColor               = [UIColor colorWithRed:0.329 green: 0.329 blue:0.329 alpha:1].CGColor;
	star.path                      = [self starPath].CGPath;
	
	CAGradientLayer* starGradient = [CAGradientLayer layer];
	starGradient.name              = @"gradient";
	CAShapeLayer* starMask         = [CAShapeLayer layer];
	starMask.path                  = star.path;
	starGradient.mask              = starMask;
	starGradient.frame             = star.bounds;
	starGradient.colors            = @[(id)[UIColor colorWithRed:0.328 green: 0.922 blue:0.263 alpha:1].CGColor, (id)[UIColor whiteColor].CGColor];
	[star addSublayer:starGradient];
	[self.layer addSublayer:star];
	_star = star;
	
	CAShapeLayer * rectangle = [CAShapeLayer layer];
	rectangle.frame       = CGRectMake(68.23, 55.64, 15.88, 15.39);
	rectangle.fillColor   = [UIColor colorWithRed:0.922 green: 0.579 blue:0.124 alpha:1].CGColor;
	rectangle.strokeColor = [UIColor colorWithRed:0.957 green: 1 blue:0.99 alpha:1].CGColor;
	rectangle.path        = [self rectanglePath].CGPath;
	[self.layer addSublayer:rectangle];
	_rectangle = rectangle;
}


- (IBAction)startAllAnimations:(id)sender{
	[self.star addAnimation:[self starAnimation] forKey:@"starAnimation"];
	[self.rectangle addAnimation:[self rectangleAnimation] forKey:@"rectangleAnimation"];
}

- (CABasicAnimation*)starAnimation{
	CABasicAnimation * transformAnim = [CABasicAnimation animationWithKeyPath:@"transform"];
	transformAnim.toValue            = [NSValue valueWithCATransform3D:CATransform3DConcat(CATransform3DConcat(CATransform3DMakeScale(0.5, 0.5, 1), CATransform3DMakeTranslation(50, 0, 0)), CATransform3DMakeRotation(-20 * M_PI/180, -0, 0, 1))];;
	transformAnim.duration           = 1;
	transformAnim.repeatCount        = INFINITY;
	transformAnim.autoreverses       = YES;
	transformAnim.fillMode = kCAFillModeBoth;
	transformAnim.removedOnCompletion = NO;
	
	return transformAnim;
}

- (CAAnimationGroup*)rectangleAnimation{
	CABasicAnimation * pathAnim = [CABasicAnimation animationWithKeyPath:@"path"];
	pathAnim.toValue            = (id)[QCMethod alignToBottomPath:[self rectanglePath] layer:_rectangle].CGPath;
	pathAnim.duration           = 1;
	pathAnim.beginTime          = 851;
	
	CAAnimationGroup *rectangleAnimGroup   = [CAAnimationGroup animation];
	rectangleAnimGroup.animations          = @[pathAnim];
	[rectangleAnimGroup.animations setValue:kCAFillModeForwards forKeyPath:@"fillMode"];
	rectangleAnimGroup.fillMode            = kCAFillModeForwards;
	rectangleAnimGroup.removedOnCompletion = NO;
	rectangleAnimGroup.duration = [QCMethod maxDurationFromAnimations:rectangleAnimGroup.animations];
	
	
	return rectangleAnimGroup;
}

#pragma mark - Bezier Path

- (UIBezierPath*)starPath{
	UIBezierPath *starPath = [UIBezierPath bezierPath];
	[starPath moveToPoint:CGPointMake(7.48, 0)];
	[starPath addLineToPoint:CGPointMake(5.169, 4.744)];
	[starPath addLineToPoint:CGPointMake(0, 5.505)];
	[starPath addLineToPoint:CGPointMake(3.74, 9.198)];
	[starPath addLineToPoint:CGPointMake(2.857, 14.412)];
	[starPath addLineToPoint:CGPointMake(7.48, 11.95)];
	[starPath addLineToPoint:CGPointMake(12.103, 14.412)];
	[starPath addLineToPoint:CGPointMake(11.22, 9.198)];
	[starPath addLineToPoint:CGPointMake(14.96, 5.505)];
	[starPath addLineToPoint:CGPointMake(9.791, 4.744)];
	[starPath closePath];
	[starPath moveToPoint:CGPointMake(7.48, 0)];
	
	return starPath;
}

- (UIBezierPath*)rectanglePath{
	UIBezierPath*  rectanglePath = [UIBezierPath bezierPathWithRect:CGRectMake(0, 0, 16, 15)];
	return rectanglePath;
}

@end