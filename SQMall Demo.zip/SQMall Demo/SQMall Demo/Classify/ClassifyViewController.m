//
//  ClassifyViewController.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/10.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "ClassifyViewController.h"
#import "CALayer+SQExtension.h"
#import "CAAnimation+SQExtension.h"
#import <CoreText/CoreText.h>

@interface ClassifyViewController ()

@property (nonatomic,strong) CAEmitterLayer * emitter;
@property (nonatomic,strong) CAEmitterCell  * cell;
@property (nonatomic,strong) CALayer        * layer;
@property (nonatomic,strong) CAShapeLayer   * shapeLayer;

@end

@implementation ClassifyViewController

- (CALayer *)layer {
    
    if (!_layer) {
        _layer = [CALayer layer];
        _layer.frame = CGRectMake(0, 0, 100, 100);
        _layer.cornerRadius  = 50;
        _layer.masksToBounds = YES;
        _layer.borderWidth   = 5;
        _layer.speed         = 10;
        _layer.borderColor = [UIColor grayColor].CGColor;
    }
    return _layer;
}

- (CAEmitterLayer *)emitter {
    
    if (!_emitter) {
        _emitter = [CAEmitterLayer layer];
        _emitter.birthRate    = 1;
        _emitter.emitterSize  = CGSizeMake(5, 5);
        _emitter.emitterShape = kCAEmitterLayerCircle;
        _emitter.emitterMode  = kCAEmitterLayerSurface;
        _emitter.renderMode   = kCAEmitterLayerAdditive;
        _emitter.lifetime     = 1;
        [self.view.layer addSublayer:_emitter];
    }
    return _emitter;
}

- (CAEmitterCell *)cell {
    
    if (!_cell) {
        _cell = [CAEmitterCell new];
        _cell.contentsScale  = [UIScreen mainScreen].scale;
        _cell.contents      = (id)[UIImage imageNamed:@"TwinkleImage"].CGImage;
        _cell.birthRate     = 100;//每秒产生cell的数量
        _cell.lifetime      = 3;//动画时长
        _cell.color         = [UIColor yellowColor].CGColor;//颜色
        _cell.alphaSpeed    = -0.1f;//射程
        _cell.velocity      = 50;//速度
        _cell.velocityRange = 50;//速度范围(随机)
        _cell.emissionRange = SQAngle(10);//发散角度
        _cell.spin          = 20;//旋转
        _cell.spinRange     = 20;//旋转范围(随机)
        _cell.scale         = 1.2;
        _cell.scaleRange    = 0;
        _cell.scaleSpeed    = 0;
        _cell.xAcceleration = -50;
        _cell.yAcceleration = 100;
    }
    return _cell;
}

- (CAShapeLayer *)shapeLayer {
    
    if (!_shapeLayer) {
        _shapeLayer = [CAShapeLayer layer];
        _shapeLayer.strokeColor = [UIColor yellowColor].CGColor;
        _shapeLayer.lineWidth = 3;
        _shapeLayer.frame = CGRectMake(0, 200, 375, 40);
        [self.view.layer addSublayer:_shapeLayer];
    }
    return _shapeLayer;
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {

    UITouch * touch              = [touches anyObject];
    CGPoint currentP             = [touch locationInView:self.view];
    self.emitter.emitterPosition = currentP;//粒子发散点
    self.emitter.emitterCells    = @[self.cell];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    self.emitter.birthRate = 0;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self animation];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view.layer setGradientWithColors:@[(__bridge id)[UIColor whiteColor].CGColor,(__bridge id)[UIColor orangeColor].CGColor] startPoint:CGPointMake(0.5, 0) endPoint:CGPointMake(0.5, 1)];
    [self.view.layer addSublayer:self.layer];
    
    [_layer setGradientWithColors:@[(__bridge id)[UIColor redColor].CGColor,(__bridge id)[UIColor orangeColor].CGColor] startPoint:CGPointMake(0.5, 0) endPoint:CGPointMake(0.5, 1)];
    [_layer setLineDashWithPath:[UIBezierPath bezierPathWithArcCenter:CGPointMake(50, 50) radius:45 startAngle:0 endAngle:SQAngle(360) clockwise:YES] lineWidth:5 lineColor:[UIColor yellowColor] lineDashPattern:@[@(5),@(5)]];
    [_layer setTextWithText:@"hahahahaha" textColor:[UIColor blackColor] font:SQFont(15)];
    [_layer addReplicatorWithSuperLayer:self.view.layer coordinate:CGPointMake(100, 100)];

}

- (void)animation {

    [CAAnimation animationRotateWithLayer:_layer repeatCount:INFINITY];
    [CAAnimation animationShakeWithLayer:_layer xy:@"x" repeatCount:INFINITY];
    
    UIBezierPath * path = [UIBezierPath bezierPath];
    [path addArcWithCenter:CGPointMake(140, 150) radius:55 startAngle:0 endAngle:SQAngle(360) clockwise:YES];
    
    CAKeyframeAnimation * ann = [CAKeyframeAnimation animation];
    ann.keyPath = @"emitterPosition";
    ann.path = path.CGPath;
    ann.duration = 1;
    ann.repeatCount = INFINITY;
    [self.emitter addAnimation:ann forKey:nil];
}

@end
