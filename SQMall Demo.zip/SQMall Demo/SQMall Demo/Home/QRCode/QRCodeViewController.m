//
//  QRCodeViewController.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/16.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "QRCodeViewController.h"
#import "UIBarButtonItem+SQExtension.h"
#import "UIColor+SQExtension.h"

@interface QRCodeViewController ()<UIGestureRecognizerDelegate>
{
 UIImageView * layer;
}
@end

@implementation QRCodeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self mask];
}

- (void)mask {
    self.tabBarItem.badgeValue = @"9";
    
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithImageName:@"magnifier_black" highlightedImageName:nil target:self action:@selector(nnnnn)];
    
    UIImageView * image = [UIImageView new];
    image.image = [UIImage imageNamed:@"women_wenzi"];
    image.frame = CGRectMake(0, 0, 375, 667);
    image.userInteractionEnabled =  YES;
    self.view.backgroundColor = [UIColor colorWithHexString:@"#ffffff"];
    [self.view addSubview:image];
    
    layer = [UIImageView new];
    layer.frame = CGRectMake(100, 100, 200, 200);
    layer.image = [UIImage imageNamed:@"maskLayerContents"];
    image.layer.mask = layer.layer;
    
    [image addGestureRecognizer:[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(nnn:)]];
}

- (void)nnnnn {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)nnn:(UIPanGestureRecognizer *)ges {
    
    CGPoint nn = [ges translationInView:ges.view];
    CGPoint center = layer.center;
    center.x += nn.x;
    center.y += nn.y;
    layer.center = center;
    [ges setTranslation:CGPointZero inView:ges.view];
    
}
@end
