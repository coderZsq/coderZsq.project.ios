//
//  BrandSetsCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/12.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "BrandSetsCell.h"
#import "BrandStreetViewController.h"

@interface BrandSetsCell ()

@property (strong, nonatomic) NSMutableArray * contentArr;
@property (strong, nonatomic) NSMutableArray * contentLayerArr;
@property (strong, nonatomic) NSMutableArray * titleArr;
@property (strong, nonatomic) NSMutableArray * subTitleArr;
@property (strong, nonatomic) NSMutableArray * arrowArr;
@property (strong, nonatomic) NSMutableArray * contentButtonArr;
@property (strong, nonatomic) NSArray        * textArr;
@property (strong, nonatomic) NSArray        * imageArr;

@property (strong, nonatomic) UIButton * backgroundButton;
@end

@implementation BrandSetsCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([BrandSetsCell class]);
    BrandSetsCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[BrandSetsCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

- (NSMutableArray *)contentArr {
    
    if (!_contentArr) {
        _contentArr = @[].mutableCopy;
    }
    return _contentArr;
}

- (NSMutableArray *)contentLayerArr {
    
    if (!_contentLayerArr) {
        _contentLayerArr = @[].mutableCopy;
    }
    return _contentLayerArr;
}

- (NSMutableArray *)titleArr {
    
    if (!_titleArr) {
        _titleArr = @[].mutableCopy;
    }
    return _titleArr;
}

- (NSMutableArray *)subTitleArr {
    
    if (!_subTitleArr) {
        _subTitleArr = @[].mutableCopy;
    }
    return _subTitleArr;
}

- (NSMutableArray *)arrowArr {
    
    if (!_arrowArr) {
        _arrowArr = @[].mutableCopy;
    }
    return _arrowArr;
}

- (NSMutableArray *)contentButtonArr {
    
    if (!_contentButtonArr) {
        _contentButtonArr = @[].mutableCopy;
    }
    return _contentButtonArr;
}

- (NSArray *)textArr {
    
    if (!_textArr) {
        _textArr = @[@"中华老字号",@"奢品汇"];
    }
    return _textArr;
}

- (NSArray *)imageArr {

    if (!_imageArr) {
        _imageArr = @[@"老字号",@"奢品会"];
    }
    return _imageArr;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    [self.contentView addSubview:self.backgroundButton];
}

- (UIButton *)backgroundButton {
    
    if (!_backgroundButton) {
        _backgroundButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _backgroundButton.adjustsImageWhenHighlighted = NO;
        [_backgroundButton setBackgroundImage:[UIImage imageNamed:@"pinpaiguan"] forState:UIControlStateNormal];
        for (int i = 0; i < 2; i++) {
            UIButton * content = [UIButton buttonWithType:UIButtonTypeCustom];
            content.adjustsImageWhenHighlighted = NO;
            content.backgroundColor = [UIColor blackColor];
            content.alpha = 0.3f;
            if ([content isKindOfClass:[UIButton class]]) {
                [self.backgroundButton addSubview:content];
                [self.contentArr addObject:content];
            }
            UIButton * contentLayer = [UIButton buttonWithType:UIButtonTypeCustom];
            contentLayer.adjustsImageWhenHighlighted = NO;
            contentLayer.backgroundColor = [UIColor clearColor];
            if ([self respondsToSelector:@selector(contentLayerClick:)]) {
                [contentLayer addTarget:self action:@selector(contentLayerClick:) forControlEvents:UIControlEventTouchUpInside];
            }
            if ([contentLayer isKindOfClass:[UIButton class]]) {
                [self.backgroundButton addSubview:contentLayer];
                [self.contentLayerArr addObject:contentLayer];
            }
            UILabel * title = [UILabel new];
            title.userInteractionEnabled = NO;
            title.font = SQFont(16);
            title.text = self.textArr[i];
            title.textColor = [UIColor whiteColor];
            if ([title isKindOfClass:[UILabel class]]) {
                [contentLayer addSubview:title];
                [self.titleArr addObject:title];
            }
            UILabel * subTitle = [UILabel new];
            subTitle.userInteractionEnabled = NO;
            subTitle.text = @"全部";
            subTitle.font = title.font;
            subTitle.textColor = title.textColor;
            subTitle.textAlignment = NSTextAlignmentRight;
            if ([subTitle isKindOfClass:[UILabel class]]) {
                [contentLayer addSubview:subTitle];
                [self.subTitleArr addObject:subTitle];
            }
            UIButton * arrowButton = [UIButton buttonWithType:UIButtonTypeCustom];
            arrowButton.userInteractionEnabled = NO;
            [arrowButton setBackgroundImage:[UIImage imageNamed:@"icon_jiantou"] forState:UIControlStateNormal];
            if ([arrowButton isKindOfClass:[UIButton class]]) {
                [contentLayer addSubview:arrowButton];
                [self.arrowArr addObject:arrowButton];
            }
            UIButton * contentButton = [UIButton buttonWithType:UIButtonTypeCustom];
            contentButton.adjustsImageWhenHighlighted = NO;
            contentButton.userInteractionEnabled = NO;
            [contentButton setBackgroundImage:[UIImage imageNamed:self.imageArr[i]] forState:UIControlStateNormal];
            if ([contentButton isKindOfClass:[UIButton class]]) {
                [contentLayer addSubview:contentButton];
                [self.contentButtonArr addObject:contentButton];
            }
        }
    }
    return _backgroundButton;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    [self layoutBackgroundButton];
}

- (void)layoutBackgroundButton {
    
    self.backgroundButton.frame = self.contentView.frame;
    CGFloat contentH = kScaleLength(80);
    CGFloat contentY = self.backgroundButton.yMax - contentH;
    CGFloat contentW = kScreenWidth * 0.5f - 1;
    for (int i = 0 ; i < self.contentArr.count; i++) {
        if (self.contentArr.count <= self.contentArr.count) {
            UIButton * content = self.contentArr[i];
            CGFloat contentX = (contentW + 1) * i;
            content.frame = CGRectMake(contentX, contentY, contentW, contentH);
        }
    }
    CGFloat contentLayerY = contentY;
    CGFloat contentLayerW = contentW;
    CGFloat contentLayerH = contentH;
    for (int i = 0 ; i < self.contentLayerArr.count; i++) {
        if (self.contentLayerArr.count <= self.contentLayerArr.count) {
            UIButton * contentLayer = self.contentLayerArr[i];
            CGFloat contentLayerX = (contentLayerW + 1) * i;;
            contentLayer.frame = CGRectMake(contentLayerX, contentLayerY, contentLayerW, contentLayerH);
        }
    }
    [self layoutContentLayer];
}

- (void)layoutContentLayer {

    CGFloat titleX = 10;
    CGFloat titleY = 10;
    CGFloat titleW = kScreenWidth * 0.25f;
    CGFloat titleH = 20;
    for (int i = 0 ; i < self.titleArr.count; i++) {
        if (self.titleArr.count <= self.titleArr.count) {
            UILabel * title = self.titleArr[i];
            title.frame = CGRectMake(titleX, titleY, titleW, titleH);
        }
    }
    
    CGFloat subTitleX = titleW;
    CGFloat subTitleY = titleY;
    CGFloat subTitleW = titleW - 20;
    CGFloat subTitleH = titleH;
    for (int i = 0 ; i < self.subTitleArr.count; i++) {
        if (self.subTitleArr.count <= self.subTitleArr.count) {
            UILabel * subTitle = self.subTitleArr[i];
            subTitle.frame = CGRectMake(subTitleX, subTitleY, subTitleW, subTitleH);
        }
    }
    
    CGFloat arrowButtonX = subTitleX + subTitleW + 3;
    CGFloat arrowButtonY = subTitleY + 3;
    CGFloat arrowButtonW = 7;
    CGFloat arrowButtonH = 13;
    for (int i = 0 ; i < self.arrowArr.count; i++) {
        if (self.arrowArr.count <= self.arrowArr.count) {
            UIButton * arrowButton = self.arrowArr[i];
            arrowButton.frame = CGRectMake(arrowButtonX, arrowButtonY, arrowButtonW, arrowButtonH);
        }
    }
    
    CGFloat contentButtonX = 20;
    CGFloat contentButtonY = titleY + titleH + kScaleLength(10);
    CGFloat contentButtonW = kScreenWidth * 0.5f - contentButtonX * 2;
    CGFloat contentButtonH = contentButtonW * 0.25f;
    for (int i = 0 ; i < self.imageArr.count; i++) {
        if (self.imageArr.count <= self.contentButtonArr.count) {
            UIButton * contentButton = self.contentButtonArr[i];
            contentButton.frame = CGRectMake(contentButtonX, contentButtonY, contentButtonW, contentButtonH);
        }
    }
}

#pragma mark - ContentLayerClick Events
- (void)contentLayerClick:(UIButton *)sender {
    [[SQViewControllerManager shareInstance].currentViewController pushViewController:[BrandStreetViewController new] animated:YES];
}

@end
