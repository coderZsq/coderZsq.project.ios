//
//  DoctorCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/14.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "DoctorCell.h"

@interface DoctorCell ()

@property (strong, nonatomic) UIButton * doctorButton;

@end

@implementation DoctorCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([DoctorCell class]);
    DoctorCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[DoctorCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    [self.contentView addSubview:self.doctorButton];
}

- (UIButton *)doctorButton {
    
    if (!_doctorButton) {
        _doctorButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _doctorButton.adjustsImageWhenHighlighted = NO;
        [_doctorButton setBackgroundImage:[UIImage imageNamed:@"yaoshi"] forState:UIControlStateNormal];
    }
    return _doctorButton;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.doctorButton.frame = self.contentView.frame;
}

@end
