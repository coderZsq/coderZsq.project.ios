//
//  BrandStreetViewController.h
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/16.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "SQTableViewController.h"

@interface BrandStreetViewController : SQTableViewController

@end
