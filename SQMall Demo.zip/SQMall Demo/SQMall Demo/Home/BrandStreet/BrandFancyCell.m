//
//  BrandFancyCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/16.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "BrandFancyCell.h"

@interface BrandFancyCell()

@property (strong, nonatomic) UIView * topView;
@property (strong, nonatomic) UIView * bottomView;

@end

@implementation BrandFancyCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([BrandFancyCell class]);
    BrandFancyCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[BrandFancyCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeSubviews];
        [self setBackgroundColor:[UIColor whiteColor]];
    }
    return self;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    [self.contentView addSubview:self.topView];
    [self.contentView addSubview:self.bottomView];
}

- (UIView *)topView {
    
    if (!_topView) {
        _topView = [UIView new];
    }
    return _topView;
}

- (UIView *)bottomView {
    
    if (!_bottomView) {
        _bottomView = [UIView new];
    }
    return _bottomView;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat topViewX = 0;
    CGFloat topViewY = 0;
    CGFloat topViewW = self.contentView.width;
    CGFloat topViewH = kScaleLength(140);
    self.topView.frame = CGRectMake(topViewX, topViewY, topViewW, topViewH);
    
    CGFloat bottomViewX = topViewX;
    CGFloat bottomViewY = topViewY + topViewH;
    CGFloat bottomViewW = topViewW;
    CGFloat bottomViewH = kScaleLength(375);
    self.bottomView.frame = CGRectMake(bottomViewX, bottomViewY, bottomViewW, bottomViewH);
}

@end
