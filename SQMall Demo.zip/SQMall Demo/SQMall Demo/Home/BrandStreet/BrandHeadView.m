//
//  BrandHeadView.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/16.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "BrandHeadView.h"

@implementation BrandHeadView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setFrame:CGRectMake(0, 0, kScreenWidth, kNavigationBarLength)];
        [self setBackgroundColor:[UIColor colorWithRed:248/255.0 green:248/255.0 blue:248/255.0 alpha:1]];
    }
    return self;
}

@end
