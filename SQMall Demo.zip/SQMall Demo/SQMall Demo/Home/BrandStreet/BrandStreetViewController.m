//
//  BrandStreetViewController.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/16.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "BrandStreetViewController.h"
#import "BrandFancyCell.h"
#import "BrandView.h"
#import "BrandHeadView.h"
#import "BrandBarView.h"

@interface BrandStreetViewController ()

@property (strong ,nonatomic) NSArray       * brandImageArr;
@property (assign ,nonatomic) NSInteger       selectSection;

@property (strong ,nonatomic) BrandBarView  * brandBarView;
@property (strong ,nonatomic) BrandBarView  * brandNavgiationBar;

@property (assign ,nonatomic ,getter = isExpend) BOOL expend;

@end

@implementation BrandStreetViewController

- (void)loadView {
    [super loadView];
    [self setTitle:@"品牌街"];
    [self.tableView setBackgroundColor:[UIColor colorWithRed:248/255.0 green:248/255.0 blue:248/255.0 alpha:1]];
    [self.tableView setTableHeaderView:[BrandHeadView new]];
    [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initializeSection];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.tabBarController.view addSubview:self.brandBarView];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.brandBarView removeFromSuperview];
}

- (void)viewDidLayoutSubviews {

    CGFloat brandBarViewX = kScaleLength(61.3f);
    CGFloat brandBarViewY = -self.tableView.contentOffset.y;
    CGFloat brandBarViewW = kScreenWidth - (kSpace * 2);
    CGFloat brandBarViewH = kNavigationBarLength;
    self.brandBarView.frame = CGRectMake(brandBarViewX, brandBarViewY, brandBarViewW, brandBarViewH);
}

#pragma mark - Lazy Loading in here
- (NSArray *)brandImageArr {
    
    if (!_brandImageArr) {
        _brandImageArr = @[@"华润出品",@"中华老字号",@"奢牌尖货"];
    }
    return _brandImageArr;
}

- (BrandBarView *)brandBarView {
    
    if (!_brandBarView) {
        _brandBarView = [BrandBarView new];
    }
    return _brandBarView;
}

- (BrandBarView *)brandNavgiationBar {

    if (!_brandNavgiationBar) {
        _brandNavgiationBar = [BrandBarView new];
        _brandNavgiationBar.frame = self.navigationController.navigationBar.frame;
    }
    return _brandNavgiationBar;
}

#pragma mark - Initialize indexPath in here
- (void)initializeSection {
    for (int i = 0; i < self.brandImageArr.count; i++) {
        [self setupSectionWithClass:[BrandFancyCell class] cellHeight:515];
    }
}

- (void)setupSectionWithClass:(Class)class cellHeight:(CGFloat)cellHeight {
    
    SQTableViewSection * section = [SQTableViewSection new];
    [self setupRowWithSection:section class:class cellHeight:cellHeight];
    if (class == [BrandFancyCell class]) {
        section.headerView = [BrandView class];
        section.headerHeight = kScaleLength(90);
    }
    [self.dataSource addObject:section];
}

- (void)setupRowWithSection:(SQTableViewSection *)section class:(Class)class cellHeight:(CGFloat)cellHeight {
    SQTableViewRow * row = [SQTableViewRow rowForTableViewCell:class cellHeight:kScaleLength(cellHeight)];
    [section.rows addObject:row];
}

#pragma mark - UITableViewDataSource
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SQTableViewSection * sections = self.dataSource[indexPath.section];
    SQTableViewRow * rows = sections.rows[indexPath.row];
    SQTableViewCell * cell = [rows.tableViewCell cellWithTableView:tableView];
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    __weak typeof(self) _self = self;
    SQTableViewSection * sections = self.dataSource[section];
    SQHeaderFooterView * headerView = [sections.headerView viewWithTableView:tableView];
    if (sections.headerView == [BrandView class]) {
        BrandView * view = (BrandView *)headerView;
        view.tag = section;
        view.brandImage = self.brandImageArr[section];
        view.block = ^(BrandView * brandView){
            if (brandView.tag != _self.selectSection) {
                _self.selectSection = brandView.tag;
                _self.expend = YES;
            }
            for (SQTableViewRow * row in sections.rows) {
                if (_self.expend) {
                    row.cellHeight = kScaleLength(515);
                } else {
                    row.cellHeight = 0;
                }
            }
            _self.expend = !_self.expend;
            [_self.tableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationAutomatic];
        };
    }
    return headerView;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    float alpha = ((kNavigationLength - scrollView.contentOffset.y) / kNavigationLength) - 1;
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[[UIColor blackColor]colorWithAlphaComponent:alpha]}];
    self.brandNavgiationBar.alpha = scrollView.contentOffset.y > -20 ? 1.0f : 0.0f;
    self.brandBarView.alpha       = scrollView.contentOffset.y > -20 ? 0.0f : 1.0f;
    [self.navigationItem setTitleView:scrollView.contentOffset.y > -20 ? self.brandNavgiationBar : nil];
}

@end
