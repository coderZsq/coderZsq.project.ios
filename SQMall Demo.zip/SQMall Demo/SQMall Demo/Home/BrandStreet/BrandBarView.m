//
//  BrandBarView.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/16.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "BrandBarView.h"

@interface BrandBarView ()

@property (strong ,nonatomic) NSArray        * titleArr;
@property (strong ,nonatomic) NSMutableArray * titleButtonArr;

@property (strong, nonatomic) UIView         * layerView;

@end

@implementation BrandBarView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

- (NSArray *)titleArr {
    
    if (!_titleArr) {
        _titleArr = @[@"精选",@"全部"];
    }
    return _titleArr;
}

- (NSMutableArray *)titleButtonArr {
    
    if (!_titleButtonArr) {
        _titleButtonArr = @[].mutableCopy;
    }
    return _titleButtonArr;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    
    [self addSubview:self.layerView];
    
    for (int i = 0; i < 2; i++) {
        UIButton * titleButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [titleButton setAdjustsImageWhenHighlighted:NO];
        [titleButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [titleButton setTitle:self.titleArr[i] forState:UIControlStateNormal];
        if ([titleButton isKindOfClass:[UIButton class]]) {
            [self.layerView addSubview:titleButton];
            [self.titleButtonArr addObject:titleButton];
        }
    }
}

- (UIView *)layerView {
    
    if (!_layerView) {
        _layerView = [UIView new];
    }
    return _layerView;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.layerView setFrame:CGRectMake(0, 0, self.width * 0.8f, self.height)];
    
    CGFloat titleButtonY = 0;
    CGFloat titleButtonW = kScaleLength(70);
    CGFloat titleButtonH = self.layerView.height;
    for (int i = 0 ; i < self.titleArr.count; i++) {
        if (self.titleArr.count <= self.titleButtonArr.count) {
            UIButton * titleButton = self.titleButtonArr[i];
            CGFloat titleButtonX = titleButtonW * i + kScaleLength(28);
            titleButton.frame = CGRectMake(titleButtonX, titleButtonY, titleButtonW, titleButtonH);
        }
    }
}
@end
