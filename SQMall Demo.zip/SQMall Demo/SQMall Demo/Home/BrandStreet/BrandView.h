//
//  BrandView.h
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/16.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BrandView;

typedef void(^BrandViewBlock)(BrandView * brandView);

@interface BrandView : UITableViewHeaderFooterView

@property (strong ,nonatomic) NSString * brandImage;

@property (copy   ,nonatomic) BrandViewBlock block;

@end
