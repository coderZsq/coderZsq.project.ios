//
//  BrandView.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/16.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "BrandView.h"

@interface BrandView ()

@property (strong ,nonatomic) UIButton * brandButton;
@property (strong ,nonatomic) UIButton * arrowButton;

@property (assign ,nonatomic,getter=isOpen) BOOL open;

@end

@implementation BrandView

+ (instancetype)viewWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([BrandView class]);
    BrandView * view = [tableView dequeueReusableHeaderFooterViewWithIdentifier:identifier];
    if (!view) {
        view = [[BrandView alloc]initWithReuseIdentifier:identifier];
    }
    return view;
}

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithReuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    [self.contentView addSubview:self.brandButton];
}

- (UIButton *)brandButton {
    
    if (!_brandButton) {
        _brandButton = [UIButton buttonWithType:UIButtonTypeCustom];
        if ([self respondsToSelector:@selector(brandButtonClick)]) {
            [_brandButton addTarget:self action:@selector(brandButtonClick) forControlEvents:UIControlEventTouchUpInside];
        }
        [_brandButton addSubview:self.arrowButton];
    }
    return _brandButton;
}

- (UIButton *)arrowButton {
    
    if (!_arrowButton) {
        _arrowButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_arrowButton setBackgroundImage:[UIImage imageNamed:@"下"] forState:UIControlStateNormal];
    }
    return _arrowButton;
}

- (void)setBrandImage:(NSString *)brandImage {
    
    _brandImage = brandImage;
    [self.brandButton setBackgroundImage:[UIImage imageNamed:brandImage] forState:UIControlStateNormal];
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.brandButton.frame = self.contentView.frame;

    CGFloat arrowButtonW = 12.5;
    CGFloat arrowButtonH = 6;
    CGFloat arrowButtonX = self.brandButton.xMax - arrowButtonW - kSpace * 2;
    CGFloat arrowButtonY = self.brandButton.yMiddle - arrowButtonH * 0.5f;
    self.arrowButton.frame = CGRectMake(arrowButtonX, arrowButtonY, arrowButtonW, arrowButtonH);
}

#pragma mark - BrandButtonClick Events
- (void)brandButtonClick {
    
    if (self.block) {
        self.block(self);
    }
}

@end
