//
//  BannersCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/12.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "BannersCell.h"

@interface BannersCell () <UIScrollViewDelegate>

@property (strong, nonatomic) NSMutableArray * bannersArr;
@property (strong, nonatomic) NSArray        * imageArr;
@property (strong, nonatomic) NSTimer        * timer;

@property (strong ,nonatomic) UIScrollView  * scrollView;
@property (strong, nonatomic) UIPageControl * pageControl;
@property (strong, nonatomic) UIButton      * firstBannerButton;
@property (strong, nonatomic) UIButton      * lastBannerButton;

@end

@implementation BannersCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([BannersCell class]);
    BannersCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[BannersCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self initializeSubviews];
    }
    return self;
}

- (NSMutableArray *)bannersArr {
    
    if (!_bannersArr) {
        _bannersArr = @[].mutableCopy;
    }
    return _bannersArr;
}

- (NSArray *)imageArr {

    if (!_imageArr) {
        _imageArr = @[@"banner11",@"banner12",@"banner13",@"banner14",@"banner15"];
    }
    return _imageArr;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    [self.contentView addSubview:self.scrollView];
    [self.contentView addSubview:self.pageControl];
    [self setupTimer];
}

- (UIScrollView *)scrollView {
    
    if (!_scrollView) {
        _scrollView = [UIScrollView new];
        _scrollView.delegate = self;
        _scrollView.bounces = NO;
        _scrollView.pagingEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator = NO;
        for (int i = 0; i < 5; i++) {
            UIButton * bannerButton = [UIButton buttonWithType:UIButtonTypeCustom];
            bannerButton.adjustsImageWhenHighlighted = NO;
            if (self.imageArr.count <= 5) {
                [bannerButton setBackgroundImage:[UIImage imageNamed:self.imageArr[i]] forState:UIControlStateNormal];
            }
            if ([bannerButton isKindOfClass:[UIButton class]]) {
                [_scrollView addSubview:bannerButton];
                [self.bannersArr addObject:bannerButton];
            }
        }
        [_scrollView addSubview:self.firstBannerButton];
        [_scrollView addSubview:self.lastBannerButton];
    }
    _scrollView.contentSize = CGSizeMake(kScreenWidth * (self.imageArr.count + 2), self.height);
    return _scrollView;
}

- (UIButton *)firstBannerButton {

    if (!_firstBannerButton) {
        _firstBannerButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _firstBannerButton.adjustsImageWhenHighlighted = NO;
        [_firstBannerButton setBackgroundImage:[UIImage imageNamed:[self.imageArr firstObject]] forState:UIControlStateNormal];
    }
    return _firstBannerButton;
}

- (UIButton *)lastBannerButton {
    
    if (!_lastBannerButton) {
        _lastBannerButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _lastBannerButton.adjustsImageWhenHighlighted = NO;
        [_lastBannerButton setBackgroundImage:[UIImage imageNamed:[self.imageArr lastObject]] forState:UIControlStateNormal];
    }
    return _lastBannerButton;
}

- (UIPageControl *)pageControl {
    
    if (!_pageControl) {
        _pageControl = [UIPageControl new];
        _pageControl.pageIndicatorTintColor = [UIColor grayColor];
        _pageControl.currentPageIndicatorTintColor = [UIColor redColor];
        _pageControl.numberOfPages = self.imageArr.count;
    }
    return _pageControl;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    [self layoutScrollView];
    
    CGFloat pageControlH = 20;
    CGFloat pageControlX = self.scrollView.x;
    CGFloat pageControlY = self.scrollView.yMax - pageControlH;
    CGFloat pageControlW = kScreenWidth;
    self.pageControl.frame = CGRectMake(pageControlX, pageControlY, pageControlW, pageControlH);
}

- (void)layoutScrollView {

    CGFloat scrollViewX = self.contentView.x;
    CGFloat scrollViewY = self.contentView.y;
    CGFloat scrollViewW = kScreenWidth;
    CGFloat scrollViewH = self.height;
    self.scrollView.frame = CGRectMake(scrollViewX, scrollViewY, scrollViewW, scrollViewH);
    
    CGFloat bannerButtonY = scrollViewX;
    CGFloat bannerButtonW = scrollViewW;
    CGFloat bannerButtonH = scrollViewH;
    for (int i = 0 ; i < self.imageArr.count; i++) {
        if (self.imageArr.count <= self.bannersArr.count) {
            UIButton * bannerButton = self.bannersArr[i];
            CGFloat bannerButtonX = bannerButtonW * (i + 1);
            bannerButton.frame = CGRectMake(bannerButtonX, bannerButtonY, bannerButtonW, bannerButtonH);
        }
    }
    
    UIButton * bannerButton = [self.bannersArr lastObject];
    CGFloat firstBannerButtonX = bannerButton.xMax;
    CGFloat firstBannerButtonY = scrollViewY;
    CGFloat firstBannerButtonW = scrollViewW;
    CGFloat firstBannerButtonH = scrollViewH;
    self.firstBannerButton.frame = CGRectMake(firstBannerButtonX, firstBannerButtonY, firstBannerButtonW, firstBannerButtonH);
    
    self.lastBannerButton.frame = self.scrollView.frame;
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    self.pageControl.currentPage = (scrollView.contentOffset.x + kScreenWidth * 0.5f) / kScreenWidth - 1;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [self.timer invalidate];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    [self setupTimer];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
    NSInteger page = (scrollView.contentOffset.x) / kScreenWidth;
    if (!page) {
        self.scrollView.contentOffset = CGPointMake(kScreenWidth * self.imageArr.count, 0);
        self.pageControl.currentPage = self.imageArr.count - 1;
    }
    else if (page == self.imageArr.count + 1) [self returnSettings];
    else self.pageControl.currentPage = page - 1;
}

#pragma mark - Setup Timer
- (void)setupTimer {
    if ([self respondsToSelector:@selector(updateTimer)]) {
        _timer = [NSTimer timerWithTimeInterval:2.5f target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
}

- (void)updateTimer {
    
    NSInteger page = self.pageControl.currentPage + 1;
    [UIView animateWithDuration:0.25f animations:^{
        self.scrollView.contentOffset = CGPointMake(kScreenWidth * (page + 1), 0);
    }];
    if (page == self.imageArr.count) [self returnSettings];
    else  self.pageControl.currentPage = page;
}

#pragma mark - Return Settings
- (void)returnSettings {
    self.scrollView.contentOffset = CGPointMake(kScreenWidth, 0);
    self.pageControl.currentPage = 0;
}

@end
