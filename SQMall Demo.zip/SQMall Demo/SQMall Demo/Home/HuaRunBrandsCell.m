//
//  HuaRunBrandsCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/12.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "HuaRunBrandsCell.h"

@interface HuaRunBrandsCell ()

@property (strong, nonatomic) NSMutableArray * huaRunBrandsArr;
@property (strong, nonatomic) NSArray        * imageArr;

@property (strong ,nonatomic) UIScrollView * scorllView;

@end

@implementation HuaRunBrandsCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([HuaRunBrandsCell class]);
    HuaRunBrandsCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[HuaRunBrandsCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

- (NSMutableArray *)huaRunBrandsArr {
    
    if (!_huaRunBrandsArr) {
        _huaRunBrandsArr = @[].mutableCopy;
    }
    return _huaRunBrandsArr;
}

- (NSArray *)imageArr {
    
    if (!_imageArr) {
        _imageArr = @[@"logo1",@"logo2",@"logo3",@"logo4"];
    }
    return _imageArr;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    [self.contentView addSubview:self.scorllView];
}

- (UIScrollView *)scorllView {
    
    if (!_scorllView) {
        _scorllView = [UIScrollView new];
        _scorllView.backgroundColor = [UIColor colorWithRed:(221) / 255.0f green:(221) / 255.0f blue:(221) / 255.0f alpha:(1.0f)];
        for (int i = 0; i < 4; i++) {
            UIButton * huaRunBrandButton = [UIButton buttonWithType:UIButtonTypeCustom];
            huaRunBrandButton.adjustsImageWhenHighlighted = NO;
            if (self.imageArr.count <= 4) {
                [huaRunBrandButton setBackgroundImage:[UIImage imageNamed:self.imageArr[i]] forState:UIControlStateNormal];
            }
            if ([huaRunBrandButton isKindOfClass:[UIButton class]]) {
                [_scorllView addSubview:huaRunBrandButton];
                [self.huaRunBrandsArr addObject:huaRunBrandButton];
            }
        }
    }
    return _scorllView;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    [self layoutScorllView];
}

- (void)layoutScorllView {
    
    self.scorllView.frame = self.contentView.frame;
    CGFloat huaRunBrandButtonY = 10;
    CGFloat huaRunBrandButtonW = kScaleLength(70);
    CGFloat huaRunBrandButtonH = huaRunBrandButtonW;
    for (int i = 0 ; i < self.huaRunBrandsArr.count; i++) {
        if (self.huaRunBrandsArr.count <= self.huaRunBrandsArr.count) {
            UIButton * huaRunBrandButton = self.huaRunBrandsArr[i];
            CGFloat huaRunBrandButtonX = (huaRunBrandButtonY + huaRunBrandButtonW)* i + huaRunBrandButtonY;
            huaRunBrandButton.frame = CGRectMake(huaRunBrandButtonX, huaRunBrandButtonY, huaRunBrandButtonW, huaRunBrandButtonH);
            self.scorllView.contentSize = CGSizeMake(CGRectGetMaxX(huaRunBrandButton.frame) + huaRunBrandButtonY, self.contentView.height);
        }
    }
}

@end
