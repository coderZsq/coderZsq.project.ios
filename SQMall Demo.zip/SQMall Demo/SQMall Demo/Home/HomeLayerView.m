//
//  HomeLayerView.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/13.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "HomeLayerView.h"

@interface HomeLayerView ()

@property (strong, nonatomic) NSMutableArray * firstCategoryArr;
@property (strong, nonatomic) NSArray        * textArr;

@property (strong, nonatomic) UIView       * buttomView;
@property (strong, nonatomic) UILabel      * title;
@property (strong, nonatomic) UIScrollView * scrollView;
@property (strong, nonatomic) UIView       * dividingLine;

@end

@implementation HomeLayerView

+ (instancetype)viewWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([HomeLayerView class]);
    HomeLayerView * view = [tableView dequeueReusableHeaderFooterViewWithIdentifier:identifier];
    if (!view) {
        view = [[HomeLayerView alloc]initWithReuseIdentifier:identifier];
    }
    return view;
}

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier {

    self = [super initWithReuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

- (NSArray *)textArr {
    
    if (!_textArr) {
        _textArr = @[@"药师推荐",@"当季高发",@"家庭药箱",@"热门排行",@"其他"];
    }
    return _textArr;
}

- (NSMutableArray *)firstCategoryArr {
    
    if (!_firstCategoryArr) {
        _firstCategoryArr = @[].mutableCopy;
    }
    return _firstCategoryArr;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    [self.contentView addSubview:self.buttomView];
    [self.contentView addSubview:self.dividingLine];
}

- (UIView *)buttomView {
    
    if (!_buttomView) {
        _buttomView = [UIView new];
        _buttomView.backgroundColor = [UIColor whiteColor];
        [_buttomView addSubview:self.title];
        [_buttomView addSubview:self.scrollView];
    }
    return _buttomView;
}

- (UILabel *)title {
    
    if (!_title) {
        _title = [UILabel new];
        _title.text = @"中意之选";
    }
    return _title;
}

- (UIScrollView *)scrollView {
    
    if (!_scrollView) {
        _scrollView = [UIScrollView new];
        _scrollView.showsHorizontalScrollIndicator = NO;
        for (int i = 0; i < self.textArr.count; i++) {
            UIButton * firstCategory = [UIButton buttonWithType:UIButtonTypeCustom];
            [firstCategory setTitle:self.textArr[i] forState:UIControlStateNormal];
            [firstCategory setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            [firstCategory setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
            firstCategory.titleLabel.font = SQFont(14);
            firstCategory.adjustsImageWhenHighlighted = NO;
            if ([firstCategory isKindOfClass:[UIButton class]]) {
                [_scrollView addSubview:firstCategory];
                [self.firstCategoryArr addObject:firstCategory];
            }
        }
    }
    return _scrollView;
}

- (UIView *)dividingLine {
    
    if (!_dividingLine) {
        _dividingLine = [UIView new];
        _dividingLine.backgroundColor = [UIColor lightGrayColor];
        _dividingLine.alpha = 0.3f;
    }
    return _dividingLine;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.buttomView.frame = self.contentView.frame;
    
    CGFloat titleX = kSpace;
    CGFloat titleY = kSpace * 2;
    CGFloat titleW = self.width - kSpace * 2;
    CGFloat titleH = 20;
    self.title.frame = CGRectMake(titleX, titleY, titleW, titleH);
    
    CGFloat scrollViewH = 40;
    CGFloat scrollViewX = self.contentView.x;
    CGFloat scrollViewY = self.contentView.height - scrollViewH;
    CGFloat scrollViewW = self.contentView.width;
    self.scrollView.frame = CGRectMake(scrollViewX, scrollViewY, scrollViewW, scrollViewH);
    
    CGFloat firstCategoryY = 0;
    CGFloat firstCategoryW = self.contentView.width * 0.22f;
    CGFloat firstCategoryH = scrollViewH;
    for (int i = 0 ; i < self.textArr.count; i++) {
        if (self.textArr.count <= self.firstCategoryArr.count) {
            UIButton * firstCategory = self.firstCategoryArr[i];
            CGFloat firstCategoryX = firstCategoryW * i;
            self.scrollView.contentSize = CGSizeMake(firstCategory.xMax, scrollViewH);
            firstCategory.frame = CGRectMake(firstCategoryX, firstCategoryY, firstCategoryW, firstCategoryH);
        }
    }
    
    CGFloat dividingLineX = 0;
    CGFloat dividingLineY = self.buttomView.yMax - 1;
    CGFloat dividingLineW = kScreenWidth;
    CGFloat dividingLineH = 1;
    self.dividingLine.frame = CGRectMake(dividingLineX, dividingLineY, dividingLineW, dividingLineH);
}

@end
