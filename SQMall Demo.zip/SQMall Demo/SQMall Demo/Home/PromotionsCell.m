//
//  PromotionsCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/12.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "PromotionsCell.h"

@interface PromotionsCell ()

@property (strong, nonatomic) NSMutableArray * promotionsArr;
@property (strong, nonatomic) NSMutableArray * dividingLineArr;
@property (strong, nonatomic) NSArray        * imageArr;

@property (strong, nonatomic) UIView         * dividingLine;

@end

@implementation PromotionsCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([PromotionsCell class]);
    PromotionsCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[PromotionsCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

- (NSMutableArray *)promotionsArr {
    
    if (!_promotionsArr) {
        _promotionsArr = @[].mutableCopy;
    }
    return _promotionsArr;
}

- (NSMutableArray *)dividingLineArr {
    
    if (!_dividingLineArr) {
        _dividingLineArr = @[].mutableCopy;
    }
    return _dividingLineArr;
}

- (NSArray *)imageArr {
    
    if (!_imageArr) {
        _imageArr = @[@"1",@"2",@"3",@"4"];
    }
    return _imageArr;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    
    for (int i = 0; i < 4; i++) {
        UIButton * promotion = [UIButton buttonWithType:UIButtonTypeCustom];
        promotion.adjustsImageWhenHighlighted = NO;
        if (self.imageArr.count <= 4) {
            [promotion setBackgroundImage:[UIImage imageNamed:self.imageArr[i]] forState:UIControlStateNormal];
        }
        if ([promotion isKindOfClass:[UIButton class]]) {
            [self.contentView addSubview:promotion];
            [self.promotionsArr addObject:promotion];
        }
    }
    
    for (int i = 0; i < 3; i++) {
        UIButton * dividingLine = [UIButton buttonWithType:UIButtonTypeCustom];
        dividingLine.adjustsImageWhenHighlighted = NO;
        dividingLine.backgroundColor = [UIColor lightGrayColor];
        dividingLine.alpha = 0.3f;
        if ([dividingLine isKindOfClass:[UIButton class]]) {
            [self.contentView addSubview:dividingLine];
            [self.dividingLineArr addObject:dividingLine];
        }
    }
    [self.contentView addSubview:self.dividingLine];
}

- (UIView *)dividingLine {
    
    if (!_dividingLine) {
        _dividingLine = [UIView new];
        _dividingLine.backgroundColor = [UIColor lightGrayColor];
        _dividingLine.alpha = 0.3f;
    }
    return _dividingLine;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat promotionY = self.contentView.y;
    CGFloat promotionW = kScreenWidth * 0.22f;
    CGFloat promotionH = self.contentView.height;
    for (int i = 0 ; i < self.imageArr.count; i++) {
        if (self.imageArr.count <= self.promotionsArr.count) {
            UIButton * promotion = self.promotionsArr[i];
            CGFloat promotionX = promotionW * i;
            if (i == 3) promotionW = kScreenWidth * 0.36f;
            promotion.frame = CGRectMake(promotionX, promotionY, promotionW, promotionH);
        }
    }
    
    CGFloat dividingLineY = promotionY;
    CGFloat dividingLineW = 1;
    CGFloat dividingLineH = promotionH;
    for (int i = 0 ; i < self.dividingLineArr.count; i++) {
        if (self.dividingLineArr.count <= self.dividingLineArr.count) {
            UIButton * dividingLine = self.dividingLineArr[i];
            CGFloat dividingLineX = ((kScreenWidth * 0.22f) - dividingLineW) * (i + 1);
            dividingLine.frame = CGRectMake(dividingLineX, dividingLineY, dividingLineW, dividingLineH);
        }
    }
    
    CGFloat dividLineH = 1;
    CGFloat dividLineX = self.contentView.x;
    CGFloat dividLineY = self.contentView.yMax - dividLineH;
    CGFloat dividLineW = self.contentView.width;
    self.dividingLine.frame = CGRectMake(dividLineX, dividLineY, dividLineW, dividLineH);
}

@end
