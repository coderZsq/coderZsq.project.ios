//
//  CrowdCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/10.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "CrowdCell.h"
#import "CrowdViewController.h"

@interface CrowdCell ()

@property (strong, nonatomic) NSMutableArray * crowdsArr;
@property (strong, nonatomic) NSArray        * imageArr;

@property (strong, nonatomic) UIView  * topView;
@property (strong, nonatomic) UILabel * titleLabel;
@property (strong, nonatomic) UILabel * subTitleLabel;

@end
@implementation CrowdCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([CrowdCell class]);
    CrowdCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[CrowdCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self initializeSubviews];
    }
    return self;
}

- (NSMutableArray *)crowdsArr {
    
    if (!_crowdsArr) {
        _crowdsArr = @[].mutableCopy;
    }
    return _crowdsArr;
}

- (NSArray *)imageArr {
    
    if (!_imageArr) {
        _imageArr = @[@"baby_wenzi",@"man_wenzi",@"women_wenzi",@"older_wenzi"];
    }
    return _imageArr;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    
    for (int i = 0; i < 4; i++) {
        UIButton * crowed = [UIButton buttonWithType:UIButtonTypeCustom];
        crowed.adjustsImageWhenHighlighted = NO;
        [crowed addTarget:self action:@selector(crowdClick) forControlEvents:64];
        [crowed setBackgroundImage:[UIImage imageNamed:self.imageArr[i]] forState:UIControlStateNormal];
        if ([crowed isKindOfClass:[UIButton class]]) {
            [self.contentView addSubview:crowed];
            [self.crowdsArr addObject:crowed];
        }
    }
    [self.contentView addSubview:self.topView];
    [self.contentView addSubview:self.titleLabel];
    [self.contentView addSubview:self.subTitleLabel];
}

- (UIView *)topView {
    
    if (!_topView) {
        _topView = [UIView new];
        _topView.backgroundColor = [UIColor whiteColor];
        _topView.alpha = 0.3f;
    }
    return _topView;
}

- (UILabel *)titleLabel {
    
    if (!_titleLabel) {
        _titleLabel = [UILabel new];
        _titleLabel.text = @"爱健康 ● 享生活";
        _titleLabel.textColor = [UIColor darkGrayColor];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _titleLabel;
}

- (UILabel  *)subTitleLabel {
    
    if (!_subTitleLabel) {
        _subTitleLabel = [UILabel new];
        _subTitleLabel.text = @"WITH YOU";
        _subTitleLabel.textColor = _titleLabel.textColor;
        _subTitleLabel.font = SQFont(14);
        _subTitleLabel.textAlignment = _titleLabel.textAlignment;
    }
    return _subTitleLabel;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat crowedY = self.contentView.y;
    CGFloat crowedW = kScreenWidth * 0.25f;
    CGFloat crowedH = self.height;
    for (int i = 0 ; i < self.crowdsArr.count; i++) {
        if (self.crowdsArr.count <= self.crowdsArr.count) {
            UIButton * crowed = self.crowdsArr[i];
            CGFloat crowedX = crowedW * i;
            crowed.frame = CGRectMake(crowedX, crowedY, crowedW, crowedH);
        }
    }
    [self layoutTopView];
}

- (void)layoutTopView {

    CGFloat topViewX = self.contentView.x;
    CGFloat topViewY = self.contentView.y;
    CGFloat topViewW = self.contentView.width;
    CGFloat topViewH = kScaleLength(44);
    self.topView.frame = CGRectMake(topViewX, topViewY, topViewW, topViewH);
    
    CGFloat titleLabelX = topViewX;
    CGFloat titleLabelY = topViewY;
    CGFloat titleLabelW = topViewW;
    CGFloat titleLabelH = topViewH * 0.5f;
    self.titleLabel.frame = CGRectMake(titleLabelX, titleLabelY, titleLabelW, titleLabelH);
    
    CGFloat subTitleLabelX = titleLabelX;
    CGFloat subTitleLabelY = titleLabelY + titleLabelH;
    CGFloat subTitleLabelW = titleLabelW;
    CGFloat subTitleLabelH = titleLabelH;
    self.subTitleLabel.frame = CGRectMake(subTitleLabelX, subTitleLabelY, subTitleLabelW, subTitleLabelH);
}

- (void)crowdClick {
    [[SQViewControllerManager shareInstance].currentViewController pushViewController:[CrowdViewController new] animated:YES];
}

@end
