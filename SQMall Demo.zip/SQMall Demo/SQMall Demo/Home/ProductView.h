//
//  ProductView.h
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/14.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProductView : UIButton

@end
