//
//  BenefitsCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/10.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "BenefitsCell.h"
#import <objc/message.h>

@interface BenefitsCell ()

@property (strong, nonatomic) UIButton * benifitsButton;

@end

@implementation BenefitsCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([BenefitsCell class]);
    BenefitsCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[BenefitsCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self initializeSubviews];
    }
    return self;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    self.cellHeight = 200;

    [self.contentView addSubview:self.benifitsButton];
}

- (UIButton *)benifitsButton {
    
    if (!_benifitsButton) {
         _benifitsButton = [UIButton buttonWithType:UIButtonTypeCustom];
         _benifitsButton.adjustsImageWhenHighlighted = NO;
         _benifitsButton.userInteractionEnabled = NO;
        [_benifitsButton setBackgroundImage:[UIImage imageNamed:@"shoupin"] forState:UIControlStateNormal];
    }
    return _benifitsButton;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.benifitsButton.frame = self.contentView.frame;
}

@end
