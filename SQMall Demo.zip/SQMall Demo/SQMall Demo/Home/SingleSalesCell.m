//
//  SingleSalesCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/12.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "SingleSalesCell.h"
#import "SingleSaleView.h"

#import "CartViewController.h"

@interface SingleSalesCell () <UIScrollViewDelegate>

@property (strong, nonatomic) NSMutableArray * singleSaleArr;

@property (strong, nonatomic) UIScrollView * scrollView;
@property (strong, nonatomic) UIPageControl * pageControl;

@end

@implementation SingleSalesCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([SingleSalesCell class]);
    SingleSalesCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[SingleSalesCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

- (NSMutableArray *)singleSaleArr {
    
    if (!_singleSaleArr) {
        _singleSaleArr = @[].mutableCopy;
    }
    return _singleSaleArr;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    [self.contentView addSubview:self.scrollView];
    [self.contentView addSubview:self.pageControl];
}

- (UIScrollView *)scrollView {
    
    if (!_scrollView) {
        _scrollView = [UIScrollView new];
        _scrollView.delegate = self;
        _scrollView.pagingEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.contentSize = CGSizeMake(kScreenWidth * 3, self.contentView.height);
        for (int i = 0; i < 3; i++) {
            SingleSaleView * singleSaleView = [SingleSaleView buttonWithType:UIButtonTypeCustom];
            if ([self respondsToSelector:@selector(singleSaleViewClick:)]) {
                [singleSaleView addTarget:self action:@selector(singleSaleViewClick:) forControlEvents:UIControlEventTouchUpInside];
            }
            if ([singleSaleView isKindOfClass:[SingleSaleView class]]) {
                [_scrollView addSubview:singleSaleView];
                [self.singleSaleArr addObject:singleSaleView];
            }
        }
    }
    return _scrollView;
}

- (UIPageControl *)pageControl {
    
    if (!_pageControl) {
        _pageControl = [UIPageControl new];
        _pageControl.numberOfPages = 3;
        _pageControl.currentPageIndicatorTintColor = [UIColor redColor];
        _pageControl.pageIndicatorTintColor = [UIColor grayColor];
    }
    return _pageControl;
}

- (void)setCountDownSeconds:(NSArray *)countDownSeconds {

    _countDownSeconds = countDownSeconds;
    
    for (int i = 0; i < countDownSeconds.count; i++) {
        if (countDownSeconds.count <= self.singleSaleArr.count) {
            SingleSaleView * singleSaleView = self.singleSaleArr[i];
            singleSaleView.second = [self.countDownSeconds[i] integerValue];
        }
    }
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.scrollView.frame = self.contentView.frame;
    
    CGFloat pageControlH = 20;
    CGFloat pageControlX = self.contentView.x;
    CGFloat pageControlY = self.contentView.height - pageControlH;
    CGFloat pageControlW = self.contentView.width;
    self.pageControl.frame = CGRectMake(pageControlX, pageControlY, pageControlW, pageControlH);
    
    CGFloat singleSaleViewY = self.contentView.y;
    CGFloat singleSaleViewW = self.contentView.width;
    CGFloat singleSaleViewH = self.contentView.height;
    for (int i = 0 ; i < self.singleSaleArr.count; i++) {
        if (self.singleSaleArr.count <= self.singleSaleArr.count) {
            SingleSaleView * singleSaleView = self.singleSaleArr[i];
            CGFloat singleSaleViewX = singleSaleViewW * i;
            singleSaleView.frame = CGRectMake(singleSaleViewX, singleSaleViewY, singleSaleViewW, singleSaleViewH);
        }
    }
}

#pragma mark - singleSaleViewClick Events
- (void)singleSaleViewClick:(SingleSaleView *)singleSaleView {
    [[SQViewControllerManager shareInstance].currentViewController pushViewController:[CartViewController new] animated:YES];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    self.pageControl.currentPage = (scrollView.contentOffset.x + kScreenWidth * 0.5f) / kScreenWidth;
}

@end
