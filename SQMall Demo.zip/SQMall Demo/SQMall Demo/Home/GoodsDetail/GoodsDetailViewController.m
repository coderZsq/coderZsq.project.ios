//
//  GoodsDetailViewController.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/15.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "GoodsDetailViewController.h"
#import <CoreText/CoreText.h>
#import "HYVerifyPhoneView.h"
#import "NSMutableAttributedString+SQExtension.h"
#import "CartViewController.h"
#import "CAAnimation+SQExtension.h"
#import "CALayer+SQExtension.h"
#import "SQDatePicker.h"

@interface GoodsDetailViewController () <UINavigationControllerDelegate, UIImagePickerControllerDelegate>
@property (nonatomic,strong) SQDatePicker    * datePicker;
@property (nonatomic,strong) UILabel * textField;
@property (nonatomic,strong) UIButton * btn;
@end

@implementation GoodsDetailViewController

- (void)loadView {
    [super loadView];
    [self.view setBackgroundColor:[UIColor whiteColor]];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.datePicker];
    [self.view addSubview:self.textField];
    [self.view addSubview:self.btn];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    
    //    CGFloat datePickerX = 40;
    //    CGFloat datePickerY = 50;
    //    CGFloat datePickerW = self.view.width;
    //    CGFloat datePickerH = 300;
    //    self.datePicker.frame = CGRectMake(datePickerX, datePickerY, datePickerW, datePickerH);
    
    CGFloat textFieldX = 0;
    CGFloat textFieldY = 350;
    CGFloat textFieldW = self.view.width;
    CGFloat textFieldH = 30;
    self.textField.frame = CGRectMake(textFieldX, textFieldY, textFieldW, textFieldH);
}

- (UILabel *)textField {
    
    if (!_textField) {
        _textField = [UILabel new];
        _textField.backgroundColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.5];
        _textField.textAlignment = NSTextAlignmentCenter;
    }
    return _textField;
}

- (SQDatePicker *)datePicker {
    
    __weak typeof(self) _self = self;
    if (!_datePicker) {
        _datePicker = [[SQDatePicker alloc]initWithFrame:CGRectMake(0, 50, self.view.width, 300)];
        _datePicker.backgroundColor = [[UIColor lightGrayColor] colorWithAlphaComponent:0.5];
        _datePicker.minimumDateFormat = @"1999年12月06日";
        _datePicker.dateFormat = @"yyyy年MM月dd日";
        _datePicker.block = ^(NSString * selectedDate){
            _self.textField.text = selectedDate;
        };
    }
    return _datePicker;
}

- (UIButton *)btn {
    
    if (!_btn) {
        _btn = [UIButton buttonWithType:UIButtonTypeContactAdd];
        _btn.frame = CGRectMake(0, 400, 40, 40);
        [_btn addTarget:self action:@selector(nn) forControlEvents:64];
    }
    return _btn;
}

- (void)nn {
    self.datePicker.pickerDate = @"2002年06月19日";
    //    [self.view addSubview:[HYVerifyPhoneView new]];
    UIImagePickerController * nn = [UIImagePickerController new];
    nn.delegate = self;
    [self presentViewController:nn animated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    self.view.layer.contents = (__bridge id)image.CGImage;
}

@end
