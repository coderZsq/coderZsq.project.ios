//
//  ProductView.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/14.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "ProductView.h"
#import "NSString+SQExtension.h"

@interface ProductView ()

@property (strong, nonatomic) UIButton * productButton;
@property (strong, nonatomic) UIView   * coverView;
@property (strong, nonatomic) UILabel  * coverLabel;
@property (strong, nonatomic) UILabel  * recomendLabel;
@property (strong, nonatomic) UILabel  * marketPrice;
@property (strong, nonatomic) UILabel  * oldPrice;

@end

@implementation ProductView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    [self addSubview:self.productButton];
    [self addSubview:self.coverView];
    [self addSubview:self.coverLabel];
    [self addSubview:self.recomendLabel];
    [self addSubview:self.marketPrice];
    [self addSubview:self.oldPrice];
}

- (UIButton *)productButton {
    
    if (!_productButton) {
        _productButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _productButton.userInteractionEnabled = NO;
        _productButton.layer.borderWidth = 0.5f;
        _productButton.layer.borderColor = [UIColor lightGrayColor].CGColor;
        [_productButton setBackgroundImage:[UIImage imageNamed:@"goods"] forState:UIControlStateNormal];
    }
    return _productButton;
}

- (UIView *)coverView {
    
    if (!_coverView) {
        _coverView = [UIView new];
        _coverView.backgroundColor = [UIColor whiteColor];
        _coverView.alpha = 0.7f;
    }
    return _coverView;
}

- (UILabel *)coverLabel {
    
    if (!_coverLabel) {
        _coverLabel = [UILabel new];
        _coverLabel.numberOfLines = 2;
        _coverLabel.text = @"汤臣倍健 维生素C片 补充维生素C 健康活力填满...";
        _coverLabel.font = SQFont(15);
        _coverLabel.textColor = [UIColor darkGrayColor];
    }
    return _coverLabel;
}

- (UILabel *)recomendLabel {
    
    if (!_recomendLabel) {
        _recomendLabel = [UILabel new];
        _recomendLabel.numberOfLines = self.coverLabel.numberOfLines;
        _recomendLabel.text = @"推荐理由: 此乃康熙当年御用补品,想必真是极好的...";
        _recomendLabel.font = self.coverLabel.font;
        _recomendLabel.textColor = [UIColor redColor];
    }
    return _recomendLabel;
}

- (UILabel *)marketPrice {
    
    if (!_marketPrice) {
        _marketPrice = [UILabel new];
        _marketPrice.text = [NSString stringWithFormat:@"￥%.2f",[@35.86 floatValue]];
        _marketPrice.textColor = [UIColor redColor];
        _marketPrice.font = SQFont(17);
    }
    return _marketPrice;
}

- (UILabel *)oldPrice {
    
    if (!_oldPrice) {
        _oldPrice = [UILabel new];
        NSString * oldPriceText = [NSString stringWithFormat:@"￥%.2f",[@3135675.831566 floatValue]];
        _oldPrice.attributedText = [NSString stringStrikethroughForString:oldPriceText color:[UIColor blackColor]];
        _oldPrice.textColor = [UIColor grayColor];
        _oldPrice.font = SQFont(14);
    }
    return _oldPrice;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat productButtonX = 0;
    CGFloat productButtonY = self.y;
    CGFloat productButtonW = self.width;
    CGFloat productButtonH = productButtonW;
    self.productButton.frame = CGRectMake(productButtonX, productButtonY, productButtonW, productButtonH);

    CGFloat coverViewH = kScaleLength(40) - 1;
    CGFloat coverViewX = productButtonX + 1;
    CGFloat coverViewY = self.productButton.yMax - coverViewH;
    CGFloat coverViewW = productButtonW - 1;
    self.coverView.frame = CGRectMake(coverViewX, coverViewY, coverViewW, coverViewH);
    
    self.coverLabel.frame = self.coverView.frame;
    
    CGFloat recomendLabelX = coverViewX;
    CGFloat recomendLabelY = self.coverLabel.yMax;
    CGFloat recomendLabelW = coverViewW;
    CGFloat recomendLabelH = coverViewH;
    self.recomendLabel.frame = CGRectMake(recomendLabelX, recomendLabelY, recomendLabelW, recomendLabelH);
    
    CGSize marketPriceSize = [self.marketPrice.text getSizeWithConstraint:CGSizeMake(MAXFLOAT, MAXFLOAT) font:self.marketPrice.font];

    CGFloat marketPriceX = recomendLabelX;
    CGFloat marketPriceY = self.recomendLabel.yMax;
    CGFloat marketPriceW = marketPriceSize.width;
    CGFloat marketPriceH = marketPriceSize.height;
    self.marketPrice.frame = CGRectMake(marketPriceX, marketPriceY, marketPriceW, marketPriceH);
    
    CGFloat oldPriceX = self.marketPrice.xMax + kSpace;
    CGFloat oldPriceY = marketPriceY - 1;
    CGFloat oldPriceW = self.width - marketPriceW;
    CGFloat oldPriceH = marketPriceH;
    self.oldPrice.frame = CGRectMake(oldPriceX, oldPriceY, oldPriceW, oldPriceH);
}

@end
