//
//  ProductCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/13.
//  Copyr  ight (c) 2015年 Castiel. All rights reserved.
//

#import "ProductCell.h"
#import "ProductView.h"
#import "GoodsDetailViewController.h"

@interface ProductCell ()

@property (strong ,nonatomic) NSMutableArray * productViewArr;

@end

@implementation ProductCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([ProductCell class]);
    ProductCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[ProductCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

- (NSMutableArray *)productViewArr {
    
    if (!_productViewArr) {
        _productViewArr = @[].mutableCopy;
    }
    return _productViewArr;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    
    for (int i = 0; i < 2; i++) {
        ProductView * productView = [ProductView new];
        productView.adjustsImageWhenHighlighted = NO;
        if ([self respondsToSelector:@selector(productViewClick)]) {
            [productView addTarget:self action:@selector(productViewClick) forControlEvents:UIControlEventTouchUpInside];
        }
        if ([productView isKindOfClass:[UIButton class]]) {
            [self.contentView addSubview:productView];
            [self.productViewArr addObject:productView];
        }
    }
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat productViewY = kSpace;
    CGFloat productViewW = kScaleLength(145);
    CGFloat productViewH = self.contentView.height - productViewY;
    CGFloat margin = (kScreenWidth - productViewW * 2) / 3;
    for (int i = 0 ; i < self.productViewArr.count; i++) {
        if (self.productViewArr.count <= self.productViewArr.count) {
            UIButton * productView = self.productViewArr[i];
            CGFloat productViewX = (margin + productViewW) * i + margin;
            productView.frame = CGRectMake(productViewX, productViewY, productViewW, productViewH);
        }
    }
}

#pragma mark - ProductView Click Events
- (void)productViewClick {
    [[SQViewControllerManager shareInstance].currentViewController pushViewController:[GoodsDetailViewController new] animated:YES];
}

@end
