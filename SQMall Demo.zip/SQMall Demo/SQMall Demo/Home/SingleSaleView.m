//
//  SingleSaleView.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/12.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "SingleSaleView.h"
#import "NSString+SQExtension.h"
#import "NSArray+SQExtension.h"

@interface SingleSaleView ()

@property (strong, nonatomic) NSMutableArray * promisesArr;
@property (strong, nonatomic) NSMutableArray * promisesButtonArr;
@property (strong, nonatomic) NSArray        * textArr;
@property (strong, nonatomic) NSMutableArray * timeRemainingArr;
@property (strong, nonatomic) NSMutableArray * colonArr;
@property (strong, nonatomic) NSTimer        * timer;

@property (strong, nonatomic) UIView   * topView;
@property (strong, nonatomic) UILabel  * saleTitleLabel;
@property (strong, nonatomic) UIView   * promisesView;
@property (strong, nonatomic) UILabel  * timeRemainingLabel;
@property (strong, nonatomic) UIView   * timeRemainingView;
@property (strong, nonatomic) UIView   * bottumView;
@property (strong, nonatomic) UIButton * saleGoodsButton;
@property (strong, nonatomic) UILabel  * goodsName;
@property (strong, nonatomic) UILabel  * marketPrice;
@property (strong, nonatomic) UILabel  * discountLabel;
@property (strong, nonatomic) UILabel  * oldPrice;
@property (strong, nonatomic) UILabel  * sloganLabel;

@end

@implementation SingleSaleView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initializeSubviews];
        [self setupTimer];
    }
    return self;
}

- (NSArray *)textArr {
    
    if (!_textArr) {
        _textArr = @[@"全网最低价",@"100%负毛利"];
    }
    return _textArr;
}

- (NSMutableArray *)promisesArr {
    
    if (!_promisesArr) {
        _promisesArr = @[].mutableCopy;
    }
    return _promisesArr;
}

- (NSMutableArray *)promisesButtonArr {
    
    if (!_promisesButtonArr) {
        _promisesButtonArr = @[].mutableCopy;
    }
    return _promisesButtonArr;
}

- (NSMutableArray *)timeRemainingArr {
    
    if (!_timeRemainingArr) {
        _timeRemainingArr = @[].mutableCopy;
    }
    return _timeRemainingArr;
}

- (NSMutableArray *)colonArr {
    
    if (!_colonArr) {
        _colonArr = @[].mutableCopy;
    }
    return _colonArr;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    [self addSubview:self.topView];
    [self addSubview:self.bottumView];
}

- (UIView *)topView {
    
    if (!_topView) {
        _topView = [UIView new];
        _topView.userInteractionEnabled = NO;
        [_topView addSubview:self.saleTitleLabel];
        [_topView addSubview:self.promisesView];
        [_topView addSubview:self.timeRemainingLabel];
        [_topView addSubview:self.timeRemainingView];
    }
    return _topView;
}

- (UILabel *)saleTitleLabel {
    
    if (!_saleTitleLabel) {
        _saleTitleLabel = [UILabel new];
        _saleTitleLabel.text = @"今日秒杀";
    }
    return _saleTitleLabel;
}

- (UIView *)promisesView {
    
    if (!_promisesView) {
        _promisesView = [UIView new];
        for (int i = 0; i < self.textArr.count; i++) {
            UIButton * promisesButton = [UIButton buttonWithType:UIButtonTypeCustom];
            promisesButton.adjustsImageWhenHighlighted = NO;
            [promisesButton setImage:[UIImage imageNamed:@"icon_gou"] forState:UIControlStateNormal];
            if ([promisesButton isKindOfClass:[UIButton class]]) {
                [_promisesView addSubview:promisesButton];
                [self.promisesButtonArr addObject:promisesButton];
            }
            UILabel * promises = [UILabel new];
            promises.font = SQFont(12);
            promises.text = self.textArr[i];
            promises.textColor = [UIColor redColor];
            if ([promises isKindOfClass:[UILabel class]]) {
                [_promisesView addSubview:promises];
                [self.promisesArr addObject:promises];
            }
        }
    }
    return _promisesView;
}

- (UILabel *)timeRemainingLabel {
    
    if (!_timeRemainingLabel) {
        _timeRemainingLabel = [UILabel new];
        _timeRemainingLabel.text = @"距结束仅剩";
        _timeRemainingLabel.font = SQFont(13);
        _timeRemainingLabel.textColor = [UIColor grayColor];
    }
    return _timeRemainingLabel;
}

- (UIView *)timeRemainingView {
    
    if (!_timeRemainingView) {
        _timeRemainingView = [UIView new];
        for (int i = 0; i < 3; i++) {
            UIButton * timeRemainningButton = [UIButton buttonWithType:UIButtonTypeCustom];
            timeRemainningButton.adjustsImageWhenHighlighted = NO;
            timeRemainningButton.backgroundColor = [UIColor colorWithRed:(52) / 255.0f green:(123) / 255.0f blue:(220) / 255.0f alpha:(1)];
            [timeRemainningButton setTitle:@"00" forState:UIControlStateNormal];
            timeRemainningButton.titleLabel.font = SQFont(14);
            if ([timeRemainningButton isKindOfClass:[UIButton class]]) {
                [_timeRemainingView addSubview:timeRemainningButton];
                [self.timeRemainingArr addObject:timeRemainningButton];
            }
        }
        for (int i = 0; i < 2; i++) {
            UILabel * colonLabel = [UILabel new];
            colonLabel.text = @":";
            if ([colonLabel isKindOfClass:[UILabel class]]) {
                [_timeRemainingView addSubview:colonLabel];
                [self.colonArr addObject:colonLabel];
            }
        }
    }
    return _timeRemainingView;
}

- (UIView *)bottumView {
    
    if (!_bottumView) {
        _bottumView = [UIView new];
        _bottumView.userInteractionEnabled = NO;
        [_bottumView addSubview:self.saleGoodsButton];
        [_bottumView addSubview:self.goodsName];
        [_bottumView addSubview:self.marketPrice];
        [_bottumView addSubview:self.discountLabel];
        [_bottumView addSubview:self.oldPrice];
        [_bottumView addSubview:self.sloganLabel];
    }
    return _bottumView;
}

- (UIButton *)saleGoodsButton {
    
    if (!_saleGoodsButton) {
        _saleGoodsButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _saleGoodsButton.adjustsImageWhenHighlighted = NO;
        [_saleGoodsButton setBackgroundImage:[UIImage imageNamed:@"singleSale"] forState:UIControlStateNormal];
    }
    return _saleGoodsButton;
}

- (UILabel *)goodsName {
    
    if (!_goodsName) {
        _goodsName = [UILabel new];
        _goodsName.text = @"飞利浦 (Philips) HX3110 声波震动牙刷";
        _goodsName.textColor = [UIColor darkGrayColor];
        _goodsName.numberOfLines = 0;
    }
    return _goodsName;
}

- (UILabel *)marketPrice {
    
    if (!_marketPrice) {
        _marketPrice = [UILabel new];
        _marketPrice.text = [NSString stringWithFormat:@"￥%.2f",[@35.86 floatValue]];
        _marketPrice.textColor = [UIColor redColor];
        _marketPrice.font = SQFont(17);
    }
    return _marketPrice;
}

- (UILabel *)discountLabel {
    
    if (!_discountLabel) {
        _discountLabel = [UILabel new];
        _discountLabel.backgroundColor = [UIColor redColor];
        _discountLabel.text = @"4.7折";
        _discountLabel.font = SQFont(14);
        _discountLabel.textAlignment = NSTextAlignmentCenter;
        _discountLabel.textColor = [UIColor whiteColor];
    }
    return _discountLabel;
}

- (UILabel *)oldPrice {
    
    if (!_oldPrice) {
        _oldPrice = [UILabel new];
        NSString * oldPriceText = [NSString stringWithFormat:@"￥%.2f",[@3135675.831566 floatValue]];
        _oldPrice.attributedText = [NSString stringStrikethroughForString:oldPriceText color:SQColor(120, 89, 37, 1)];
        _oldPrice.textColor = [UIColor grayColor];
        _oldPrice.font = SQFont(14);
    }
    return _oldPrice;
}

- (UILabel *)sloganLabel {
    
    if (!_sloganLabel) {
        _sloganLabel = [UILabel new];
        _sloganLabel.text = @"还剩200个名额";
        _sloganLabel.font = self.oldPrice.font;
        _sloganLabel.textColor = [UIColor grayColor];
    }
    return _sloganLabel;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    [self layoutTopView];
    [self layoutButtonView];
}

- (void)layoutTopView {
    
    CGFloat topViewX = 0;
    CGFloat topViewY = self.y;
    CGFloat topViewW = self.width;
    CGFloat topViewH = 70;
    self.topView.frame = CGRectMake(topViewX, topViewY, topViewW, topViewH);
    
    CGFloat saleTitleX = 10;
    CGFloat saleTitleY = 15;
    CGFloat saleTitleW = self.width * 0.5f;
    CGFloat saleTitleH = 20;
    self.saleTitleLabel.frame = CGRectMake(saleTitleX, saleTitleY, saleTitleW, saleTitleH);
    
    CGFloat promisesViewW = 100;
    CGFloat promisesViewX = self.width - promisesViewW;
    CGFloat promisesViewY = self.y;
    CGFloat promisesViewH = topViewH;
    self.promisesView.frame = CGRectMake(promisesViewX, promisesViewY, promisesViewW, promisesViewH);
    
    [self layoutPromisesView];
    CGSize timeRemainingLabelSize = [self.timeRemainingLabel.text getSizeWithConstraint:CGSizeMake(MAXFLOAT,saleTitleH) font:self.timeRemainingLabel.font];
    CGFloat timeRemainingLabelX = saleTitleX + kSpace;
    CGFloat timeRemainingLabelY = self.saleTitleLabel.yMax + kSpace;
    CGFloat timeRemainingLabelW = timeRemainingLabelSize.width;
    CGFloat timeRemainingLabelH = timeRemainingLabelSize.height;
    self.timeRemainingLabel.frame = CGRectMake(timeRemainingLabelX, timeRemainingLabelY, timeRemainingLabelW, timeRemainingLabelH);
    
    CGFloat timeRemainingViewX = self.timeRemainingLabel.xMax + kSpace;
    CGFloat timeRemainingViewY = self.saleTitleLabel.yMax;
    CGFloat timeRemainingViewW = saleTitleW;
    CGFloat timeRemainingViewH = 25;
    self.timeRemainingView.frame = CGRectMake(timeRemainingViewX, timeRemainingViewY, timeRemainingViewW, timeRemainingViewH);
    
    [self layoutTimeRemainingView];
}

- (void)layoutPromisesView {
    
    CGFloat promisesButtonX = 0;
    CGFloat promisesButtonW = 12;
    CGFloat promisesButtonH = promisesButtonW;
    for (int i = 0 ; i < self.textArr.count; i++) {
        if (self.textArr.count <= self.promisesButtonArr.count) {
            UIButton * promisesButton = self.promisesButtonArr[i];
            CGFloat promisesButtonY = (promisesButtonH + 5) * i + 15;
            promisesButton.frame = CGRectMake(promisesButtonX, promisesButtonY, promisesButtonW, promisesButtonH);
        }
    }
    
    CGFloat promisesX = promisesButtonW + 5;
    CGFloat promisesW = 100;
    CGFloat promisesH = promisesButtonH;
    for (int i = 0 ; i < self.textArr.count; i++) {
        if (self.textArr.count <= self.promisesArr.count) {
            UILabel * promises = self.promisesArr[i];
            CGFloat promisesY = (promisesH + 5) * i + 15;
            promises.frame = CGRectMake(promisesX, promisesY, promisesW, promisesH);
        }
    }
}

- (void)layoutTimeRemainingView {
    
    CGFloat timeRemainningButtonY = kSpace * 0.5f;
    CGFloat timeRemainningButtonW = self.timeRemainingView.height;
    CGFloat timeRemainningButtonH = timeRemainningButtonW;
    for (int i = 0 ; i < self.timeRemainingArr.count; i++) {
        if (self.timeRemainingArr.count <= self.timeRemainingArr.count) {
            UIButton * timeRemainningButton = self.timeRemainingArr[i];
            CGFloat timeRemainningButtonX = (timeRemainningButtonW + kSpace) * i;
            timeRemainningButton.frame = CGRectMake(timeRemainningButtonX, timeRemainningButtonY, timeRemainningButtonW, timeRemainningButtonH);
        }
    }
    
    CGFloat colonLabelY = timeRemainningButtonY;
    CGFloat colonLabelW = kSpace;
    CGFloat colonLabelH = timeRemainningButtonH;
    for (int i = 0 ; i < self.colonArr.count; i++) {
        if (self.colonArr.count <= self.colonArr.count) {
            UIButton * colonLabel = self.colonArr[i];
            CGFloat colonLabelX = timeRemainningButtonW + kSpace * 0.25f + (timeRemainningButtonW + kSpace) * i;
            colonLabel.frame = CGRectMake(colonLabelX, colonLabelY, colonLabelW, colonLabelH);
        }
    }
}

- (void)layoutButtonView {
    
    CGFloat buttonViewX = 0;
    CGFloat buttonViewY = self.topView.yMax;
    CGFloat buttonViewW = self.topView.width;
    CGFloat buttonViewH = self.height - self.topView.height;
    self.bottumView.frame = CGRectMake(buttonViewX, buttonViewY, buttonViewW, buttonViewH);
    
    CGFloat saleGoodsButtonX = kSpace;
    CGFloat saleGoodsButtonY = kSpace;
    CGFloat saleGoodsButtonW = kScaleLength(100);
    CGFloat saleGoodsButtonH = saleGoodsButtonW;
    self.saleGoodsButton.frame = CGRectMake(saleGoodsButtonX, saleGoodsButtonY, saleGoodsButtonW, saleGoodsButtonH);
    
    CGSize goodsNameSize = [self.goodsName.text getSizeWithConstraint:CGSizeMake(self.width - (kSpace * 3) - saleGoodsButtonW, MAXFLOAT) font:self.goodsName.font];
    CGFloat goodsNameX = saleGoodsButtonX + saleGoodsButtonW + kSpace;
    CGFloat goodsNameY = saleGoodsButtonY;
    CGFloat goodsNameW = goodsNameSize.width;
    CGFloat goodsNameH = goodsNameSize.height;
    self.goodsName.frame = CGRectMake(goodsNameX, goodsNameY, goodsNameW, goodsNameH);
    
    CGSize marketPriceSize = [self.marketPrice.text getSizeWithConstraint:CGSizeMake(MAXFLOAT, MAXFLOAT) font:self.marketPrice.font];

    CGFloat marketPriceX = goodsNameX;
    CGFloat marketPriceY = goodsNameY + goodsNameH + kSpace;
    CGFloat marketPriceW = marketPriceSize.width;
    CGFloat marketPriceH = marketPriceSize.height;
    self.marketPrice.frame = CGRectMake(marketPriceX, marketPriceY, marketPriceW, marketPriceH);

    CGSize discountLabelSize = [self.discountLabel.text getSizeWithConstraint:CGSizeMake(MAXFLOAT, 20) font:SQFont(17)];
    CGFloat discountLabelX = marketPriceX + marketPriceW + kSpace;
    CGFloat discountLabelY = marketPriceY;
    CGFloat discountLabelW = discountLabelSize.width;
    CGFloat discountLabelH = discountLabelSize.height;
    self.discountLabel.frame = CGRectMake(discountLabelX, discountLabelY, discountLabelW, discountLabelH);

    CGFloat oldPriceX = marketPriceX;
    CGFloat oldPriceY = marketPriceY + marketPriceH;
    CGFloat oldPriceW = self.width - saleGoodsButtonW;
    CGFloat oldPriceH = marketPriceH;
    self.oldPrice.frame = CGRectMake(oldPriceX, oldPriceY, oldPriceW, oldPriceH);
    
    CGFloat sloganLabelX = marketPriceX;
    CGFloat sloganLabelY = oldPriceY + oldPriceH;
    CGFloat sloganLabelW = oldPriceW;
    CGFloat sloganLabelH = marketPriceH;
    self.sloganLabel.frame = CGRectMake(sloganLabelX, sloganLabelY, sloganLabelW, sloganLabelH);
}

#pragma mark - Setup Timer
- (void)setupTimer {

    if ([self respondsToSelector:@selector(countDownWithTiming)]) {
        self.timer = [NSTimer timerWithTimeInterval:1.0f target:self selector:@selector(countDownWithTiming) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
    } 
}

- (void)countDownWithTiming {
 
    if (!self.second) {
        [self.timer invalidate];
        return;
    }
    self.second--;
    [self updateWithTime:self.second];
}

- (void)updateWithTime:(NSInteger)second {
    
    for (int i = 0; i < self.timeRemainingArr.count; i++) {
        UIButton * timeRemainningButton = self.timeRemainingArr[i];
        timeRemainningButton.titleLabel.adjustsFontSizeToFitWidth = YES;
        [timeRemainningButton setTitle:[NSArray arrayWithCountDownTime:second][i] forState:UIControlStateNormal];
    }
}

@end
