//
//  HuaRunCorporationCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/12.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "HuaRunCorporationCell.h"

@interface HuaRunCorporationCell ()

@property (strong, nonatomic) UIButton * huaRunCorporationButton;

@end

@implementation HuaRunCorporationCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([HuaRunCorporationCell class]);
    HuaRunCorporationCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[HuaRunCorporationCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    [self.contentView addSubview:self.huaRunCorporationButton];
}

- (UIButton *)huaRunCorporationButton {
    
    if (!_huaRunCorporationButton) {
        _huaRunCorporationButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _huaRunCorporationButton.adjustsImageWhenHighlighted = NO;
        _huaRunCorporationButton.userInteractionEnabled = NO;
        [_huaRunCorporationButton setBackgroundImage:[UIImage imageNamed:@"dapaiguan1"] forState:UIControlStateNormal];
    }
    return _huaRunCorporationButton;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.huaRunCorporationButton.frame = self.contentView.frame;
}

@end
