//
//  NavigationBarView.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/15.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "NavigationBarView.h"
#import "QRCodeViewController.h"

@interface NavigationBarView ()

@property (strong, nonatomic) UIView      * layerView;
@property (strong, nonatomic) UIView      * coverView;
@property (strong, nonatomic) UITextField * textField;
@property (strong, nonatomic) UIButton    * serachButton;
@property (strong, nonatomic) UIButton    * scanButton;

@end

@implementation NavigationBarView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

#pragma mark - InitializeSubviews in here
- (void)initializeSubviews {
    [self addSubview:self.layerView];
}

- (UIView *)layerView {
    
    if (!_layerView) {
        _layerView = [UIView new];
        [_layerView addSubview:self.coverView];
        [_layerView addSubview:self.textField];
        [_layerView addSubview:self.serachButton];
        [_layerView addSubview:self.scanButton];
    }
    return _layerView;
}

- (UIView *)coverView {
    
    if (!_coverView) {
        _coverView = [UIView new];
        _coverView.backgroundColor = [UIColor whiteColor];
        _coverView.layer.cornerRadius = 2;
        _coverView.layer.masksToBounds = YES;
        _coverView.alpha = 0.8f;
    }
    return _coverView;
}

- (UITextField *)textField {
    
    if (!_textField) {
        _textField = [UITextField new];
        _textField.placeholder = @"搜索商品名/症状/疾病名";
        _textField.font = [UIFont systemFontOfSize:(15)*[UIScreen mainScreen].bounds.size.width / 320.0f];
        [_textField setValue:[UIColor darkGrayColor] forKeyPath:@"placeholderLabel.textColor"];
    }
    return _textField;
}

- (UIButton *)serachButton {
    
    if (!_serachButton) {
        _serachButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_serachButton setImage:[UIImage imageNamed:@"magnifier_black"] forState:UIControlStateNormal];
    }
    if ([self respondsToSelector:@selector(scanButtonClick)]) {
        [_scanButton addTarget:self action:@selector(scanButtonClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _serachButton;
}

- (UIButton *)scanButton {
    
    if (!_scanButton) {
        _scanButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_scanButton setImage:[UIImage imageNamed:@"icon_scanning"] forState:UIControlStateNormal];
    }
    return _scanButton;
}

#pragma mark - LayoutSubviews in here
- (void)layoutSubviews {
    [super layoutSubviews];
    [self.layerView setFrame:CGRectMake(0, 0, kScreenWidth, kNavigationBarLength)];
    [self layoutLayerView];
}

- (void)layoutLayerView {
    
    CGFloat coverViewX = 0;
    CGFloat coverViewY = 3;
    CGFloat coverViewW = kScreenWidth - 55;
    CGFloat coverViewH = 34;
    self.coverView.frame = CGRectMake(coverViewX, coverViewY, coverViewW, coverViewH);
    
    CGFloat textFieldX = coverViewX + kSpace;
    CGFloat textFieldY = coverViewY;
    CGFloat textFieldW = coverViewW * 0.7f;
    CGFloat textFieldH = coverViewH;
    self.textField.frame = CGRectMake(textFieldX, textFieldY, textFieldW, textFieldH);
  
    CGFloat serachButtonW = 17;
    CGFloat serachButtonX = self.coverView.xMax - serachButtonW - kSpace;
    CGFloat serachButtonY = textFieldY + kSpace;
    CGFloat serachButtonH = serachButtonW;
    self.serachButton.frame = CGRectMake(serachButtonX, serachButtonY, serachButtonW, serachButtonH);
    
    CGFloat scanButtonW = coverViewH;
    CGFloat scanButtonX = kScreenWidth - scanButtonW - kSpace * 2;
    CGFloat scanButtonY = kSpace - 4.5f;
    CGFloat scanButtonH = scanButtonW;
    self.scanButton.frame = CGRectMake(scanButtonX, scanButtonY, scanButtonW, scanButtonH);
}

- (void)scanButtonClick {
    
    [[SQViewControllerManager shareInstance].currentViewController pushViewController:[QRCodeViewController new] animated:YES];
}

@end
