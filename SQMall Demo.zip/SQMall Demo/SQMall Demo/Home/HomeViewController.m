//
//  HomeViewController.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/10.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "HomeViewController.h"

#import "SQTableViewCell.h"
#import "BenefitsCell.h"
#import "CrowdCell.h"
#import "BannersCell.h"
#import "PromotionsCell.h"
#import "HuaRunCorporationCell.h"
#import "HuaRunBrandsCell.h"
#import "BrandSetsCell.h"
#import "SingleSalesCell.h"
#import "ProductCell.h"
#import "HomeLayerView.h"
#import "DoctorCell.h"
#import "NavigationBarView.h"
#import "SQInfiniteLoopCell.h"
#import "SQBenifitsViewController.h"
#import "HuaRunViewController.h"
#import "ClassifyViewController.h"
#import "MeViewController.h"

@interface HomeViewController ()

@property (strong, nonatomic) UIButton          * scrollToTopButton;
@property (strong, nonatomic) NavigationBarView * navigationbar;
@property (strong, nonatomic) NavigationBarView * navigationbarView;

@end

@implementation HomeViewController

#pragma mark - Life cycle in here
- (void)loadView {
    [super loadView];
    [self.navigationItem setTitleView:self.navigationbar];
    [self.navigationController.navigationBar setShadowImage:[UIImage imageWithColor:[UIColor clearColor]
                                                                               size:CGSizeMake(kScreenWidth, 1)]];
    [self.navigationController.view addSubview:self.scrollToTopButton];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initializeSection];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.tabBarController.view addSubview:self.navigationbarView];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationbarView removeFromSuperview];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    
    CGFloat navigationbarViewH = self.navigationbar.height;
    CGFloat navigationbarViewW = self.navigationbar.width;
    CGFloat navigationbarViewX = kSpace;
    CGFloat navigationbarViewY = kScaleLength(160.5) - self.tableView.contentOffset.y - navigationbarViewH;
    self.navigationbarView.frame = CGRectMake(navigationbarViewX, navigationbarViewY, navigationbarViewW, navigationbarViewH);

    CGFloat scrollToTopButtonW = 44;
    CGFloat scrollToTopButtonH = scrollToTopButtonW;
    CGFloat scrollToTopButtonX = kScreenWidth - scrollToTopButtonW - kSpace;
    CGFloat scrollToTopButtonY = kScreenHeight - kTabbarLength - scrollToTopButtonH - kSpace;
    self.scrollToTopButton.frame = CGRectMake(scrollToTopButtonX, scrollToTopButtonY, scrollToTopButtonW, scrollToTopButtonH);
}

#pragma mark - Lazy loading in here
- (UIButton *)scrollToTopButton {
    
    if (!_scrollToTopButton) {
        _scrollToTopButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_scrollToTopButton setBackgroundImage:[UIImage imageNamed:@"icon_top"] forState:UIControlStateNormal];
        if ([self respondsToSelector:@selector(scrollToTop)]) {
            [_scrollToTopButton addTarget:self action:@selector(scrollToTop) forControlEvents:UIControlEventTouchUpInside];
        }
    }
    return _scrollToTopButton;
}

- (NavigationBarView *)navigationbar {
    
    if (!_navigationbar) {
        _navigationbar = [NavigationBarView new];
        _navigationbar.frame = self.navigationController.navigationBar.frame;
    }
    return _navigationbar;
}

- (NavigationBarView *)navigationbarView {
    
    if (!_navigationbarView) {
        _navigationbarView = [NavigationBarView new];
    }
    return _navigationbarView;
}

#pragma mark - Initialize indexPath in here
- (void)initializeSection {
    
    [self setupSectionWithClass:[BenefitsCell          class] cellHeight:160.5f];
    [self setupSectionWithClass:[CrowdCell             class] cellHeight:160.5f];
    [self setupSectionWithClass:[SQInfiniteLoopCell    class] cellHeight:140.0f];
    [self setupSectionWithClass:[PromotionsCell        class] cellHeight:119.0f];
    [self setupSectionWithClass:[HuaRunCorporationCell class] cellHeight:120.5f];
    [self setupSectionWithClass:[HuaRunBrandsCell      class] cellHeight: 90.0f];
    [self setupSectionWithClass:[BrandSetsCell         class] cellHeight:135.0f];
    [self setupSectionWithClass:[SingleSalesCell       class] cellHeight:210.0f];
    [self setupSectionWithClass:[DoctorCell            class] cellHeight:100.0f];
}

- (void)setupSectionWithClass:(Class)class cellHeight:(CGFloat)cellHeight {
    
    SQTableViewSection * section = [SQTableViewSection new];
    [self setupRowWithSection:section class:class cellHeight:cellHeight];
    if (class == [DoctorCell class]) {
        section.headerView = [HomeLayerView class];
        section.headerHeight = 88;
        for (int i = 0; i < 10; i++) {
            [self setupRowWithSection:section class:[ProductCell class] cellHeight:225.0f];
        }
    }
    [self.dataSource addObject:section];
}

- (void)setupRowWithSection:(SQTableViewSection *)section class:(Class)class cellHeight:(CGFloat)cellHeight {
    SQTableViewRow * row = [SQTableViewRow rowForTableViewCell:class cellHeight:kScaleLength(cellHeight)];
    [section.rows addObject:row];
}

#pragma mark - Scroll to top Events
- (void)scrollToTop {
    [self.tableView setContentOffset:CGPointZero animated:YES];
}

#pragma mark - UITableViewDataSource
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SQTableViewSection * sections = self.dataSource[indexPath.section];
    SQTableViewRow * rows = sections.rows[indexPath.row];
    SQTableViewCell * cell = [rows.tableViewCell cellWithTableView:tableView];
    if ([cell isKindOfClass:[SingleSalesCell class]]) {
        SingleSalesCell * singleCell = (SingleSalesCell *)cell;
        singleCell.countDownSeconds = @[@3600,@7200,@14009];
        return cell;
    }
    if ([cell isKindOfClass:[SQInfiniteLoopCell class]]) {
        SQInfiniteLoopCell * infiniteCell = (SQInfiniteLoopCell *)cell;
        infiniteCell.pageIndicatorTintColor = [UIColor grayColor];
        infiniteCell.currentPageIndicatorTintColor = [UIColor redColor];
        infiniteCell.timeInterval = 5;
        infiniteCell.infiniteLoopData = @[@"banner12",@"banner14",@"banner11",@"banner13",@"banner15"];
        return cell;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    SQTableViewSection * sections = self.dataSource[indexPath.section];
    SQTableViewRow * rows = sections.rows[indexPath.row];
    if (rows.tableViewCell == [BenefitsCell class]) {
        [self.navigationController pushViewController:[SQBenifitsViewController new] animated:YES];
    }
    if (rows.tableViewCell == [HuaRunCorporationCell class]) {
        [self.navigationController pushViewController:[HuaRunViewController new] animated:YES];
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    SQTableViewSection * sections = self.dataSource[section];
    SQHeaderFooterView * headerView = [sections.headerView viewWithTableView:tableView];
    return headerView;
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    scrollView.contentInset = UIEdgeInsetsMake(scrollView.contentOffset.y < kScaleLength(100) ? 0 : kNavigationLength, 0, kTabbarLength, 0);
    float alpha = 1 - ((kNavigationLength + 30 - scrollView.contentOffset.y) / kNavigationLength);
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageWithColor:[SQColor(248, 248, 248, 1) colorWithAlphaComponent:alpha > 0.95f ? 0.95f : alpha] size:CGSizeMake(kScreenWidth, 64)] forBarMetrics:UIBarMetricsDefault];
    
    self.navigationbar    .alpha = scrollView.contentOffset.y > kScaleLength(100.5f) ? 1.0f : 0.0f;
    self.navigationbarView.alpha = scrollView.contentOffset.y > kScaleLength(100.5f) ? 0.0f : 1.0f;
    self.scrollToTopButton.alpha = scrollView.contentOffset.y < kScaleLength(1085)   ? 0.0f : 1.0f;
}

@end
