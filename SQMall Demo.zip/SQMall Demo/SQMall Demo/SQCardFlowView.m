//
//  SQCardFlowView.m
//
//  Created by Doubles_Z on 15/9/5.
//  Copyright (c) 2015年 Doubles_Z. All rights reserved.
//

#import "SQCardFlowView.h"

@interface SQCardFlowView () <UICollectionViewDataSource,UICollectionViewDelegate>

@property (nonatomic,strong) UICollectionView           * collectionView;
@property (nonatomic,strong) UICollectionViewFlowLayout * flowLayout;

@end

@implementation SQCardFlowView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

- (UICollectionViewFlowLayout *)flowLayout {
    
    if (!_flowLayout) {
        _flowLayout = [UICollectionViewFlowLayout new];
        _flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        _flowLayout.itemSize = CGSizeMake(self.height, self.height);
        _flowLayout.sectionInset = UIEdgeInsetsMake(0, 0.5f *(self.width -self.height) , 0, 0.5f *(self.width -self.height));
    }
    return _flowLayout;
}

- (UICollectionView *)collectionView {
    
    if (!_collectionView) {
        _collectionView = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:[UICollectionViewFlowLayout new]];
        [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"CardFlowCell"];
        _collectionView.showsHorizontalScrollIndicator = NO;
        _collectionView.contentInset    = UIEdgeInsetsMake(-65, 0, 0, 0);
        _collectionView.backgroundColor = [UIColor lightGrayColor];
        _collectionView.dataSource      = self;
        _collectionView.delegate        = self;
    }
    return _collectionView;
}

- (void)setCards:(NSArray *)cards {
    _cards = cards;
}

- (void)initializeSubviews {
    [self addSubview:self.collectionView];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.collectionView setFrame:self.bounds];
    [self.collectionView setCollectionViewLayout:self.flowLayout];
    [self scrollViewDidScroll:self.collectionView];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.cards.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    return [collectionView dequeueReusableCellWithReuseIdentifier:@"CardFlowCell" forIndexPath:indexPath];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    __weak typeof(self) _self = self;
    CGFloat pathY = self.collectionView.y;
    CGFloat pathW = self.collectionView.height;
    CGFloat pathH = [UIApplication sharedApplication].keyWindow.height;
    CGFloat pathX = self.collectionView.width * 0.5f - pathW;
    CGRect  path  = CGRectMake(pathX, pathY, pathW, pathH);
    [self.collectionView.visibleCells enumerateObjectsUsingBlock:^(UICollectionViewCell * cell, NSUInteger idx, BOOL * _Nonnull stop) {
        CGPoint point = [scrollView convertPoint:cell.frame.origin toView:[UIApplication sharedApplication].keyWindow];
        CGRectContainsPoint(path, point) ? [_self animationWithCell:cell ratio:1] : [_self animationWithCell:cell ratio:0.7f];
    }];
}
- (void)animationWithCell:(UICollectionViewCell *)cell ratio:(CGFloat)ratio {
    [UIView animateWithDuration:0.25 animations:^{
        cell.contentView.transform = CGAffineTransformMakeScale(ratio, ratio);
    }];
}

@end
