//
//  SQBundleVersionManager.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/12/14.
//  Copyright © 2015年 Castiel. All rights reserved.
//

#import "SQBundleVersionManager.h"
#import "SQTabBarController.h"
#import "SQNewFeatureViewController.h"
#import "HomeViewController.h"
#import "ClassifyViewController.h"
#import "DiscoverViewController.h"
#import "CartViewController.h"
#import "MeViewController.h"
#import "SQCombineViewController.h"

@implementation SQBundleVersionManager

+ (instancetype)manager {
    return [[self alloc]init];
}

- (void)setWindow:(UIWindow *)window {
    _window = window; [self prepareForBundleVersionKey];
}

- (void)prepareForBundleVersionKey {
    
    NSString *key = @"CFBundleVersion";
    
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    NSString * lastVersion    = [[NSUserDefaults standardUserDefaults] stringForKey:key];
    NSString * currentVersion = [NSBundle mainBundle].infoDictionary[key];
    
    if ([currentVersion isEqualToString:lastVersion]) {
        self.window.rootViewController = [self getCombineViewController];
    } else {
        self.window.rootViewController = [self getNewFeatureController];
        [defaults setObject:currentVersion forKey:key];
        [defaults synchronize];
    }
}

- (SQNewFeatureViewController *)getNewFeatureController {
    
    __weak typeof(self) _self = self;
    SQNewFeatureViewController * newfeature = [SQNewFeatureViewController new];
    newfeature.newfeatureImages = @[@"app_start_1",@"app_start_2",@"app_start_3",@"app_start_4",@"app_start_5"];
    newfeature.enterButtonImage = [UIImage imageNamed:@"new_feature_finish_button_highlighted"];
    newfeature.block = ^{
        _self.window.rootViewController = [self getCombineViewController];
    };
    return newfeature;
}

- (SQCombineViewController *)getCombineViewController {
    
    SQCombineViewController * vc = [SQCombineViewController controllerWithViewController:[self getTabbarController] sidebarViewController:[HomeViewController new]];
    return vc;
}

- (SQTabBarController *)getTabbarController {
    
    return [SQTabBarController tabbarWithViewControllers:@[[HomeViewController     new],
                                                           [ClassifyViewController new],
                                                           [DiscoverViewController new],
                                                           [CartViewController     new],
                                                           [MeViewController       new]]
                                                  titles:@[ @"首页",
                                                            @"分类",
                                                            @"发现",
                                                            @"购物车",
                                                            @"我"]
                                              imageNames:@[@"tabbar_home_os7",
                                                           @"tabbar_message_center_os7",
                                                           @"tabbar_discover_os7",
                                                           @"tabbar_profile_os7",
                                                           @"tabbar_compose_icon_add"]
                                      selectedImageNames:@[@"tabbar_home_selected_os7",
                                                           @"tabbar_message_center_selected_os7",
                                                           @"tabbar_discover_selected_os7",
                                                           @"tabbar_profile_selected_os7",
                                                           @"tabbar_compose_icon_add_highlighted"]];
}
@end
