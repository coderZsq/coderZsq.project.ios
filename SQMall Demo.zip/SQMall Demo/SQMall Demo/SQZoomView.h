//
//  SQZoomView.h
//
//  Created by Doubles_Z on 15/9/5.
//  Copyright (c) 2015年 Doubles_Z. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQZoomView : UIView

@property (nonatomic,strong) UIScrollView * attachView;

@property (nonatomic,strong) UIImage * image;

@property (nonatomic,assign) CGFloat height;

- (void)zoomWithScrollView:(UIScrollView *)scrollView;

@end
