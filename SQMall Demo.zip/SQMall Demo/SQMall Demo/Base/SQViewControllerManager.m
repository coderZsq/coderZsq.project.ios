//
//  SQViewControllerManager.m
//
//  Created by Doubles_Z on 15/9/5.
//  Copyright (c) 2015年 Doubles_Z. All rights reserved.
//

#import "SQViewControllerManager.h"

@implementation SQViewControllerManager

+ (SQViewControllerManager *)shareInstance {
    
    static dispatch_once_t onceToken;
    static SQViewControllerManager * manager =nil;
    dispatch_once(&onceToken, ^{
        manager = [SQViewControllerManager new];
    });
    return manager;
}

- (SQTableViewController *)currentViewController
{
    return _currentViewController;
}

@end
