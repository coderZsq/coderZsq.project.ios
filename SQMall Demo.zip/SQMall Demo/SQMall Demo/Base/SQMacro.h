//
//  SQMacro.h
//
//  Created by Doubles_Z on 15/9/5.
//  Copyright (c) 2015年 Doubles_Z. All rights reserved.
//

#ifndef SQMacro_h
#define SQMacro_h

#import "SQTableViewSection.h"
#import "SQTableViewRow.h"
#import "SQViewControllerManager.h"
#import "SQTableViewController.h"
#import "SQTableViewCell.h"
#import "SQHeaderFooterView.h"

#import "NSString+SQExtension.h"
#import "UIImage+SQExtension.h"
#import "UIView+SQExtension.h"

#define SQLog(format, ... ) NSLog( @"<%@> %@", [[NSString stringWithUTF8String:__FILE__] lastPathComponent], [NSString stringWithFormat:(format), ##__VA_ARGS__] )

#define SQColor(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]
#define SQAngle(x) ((x) / 180.0f * M_PI)
#define SQFont(size) [UIFont systemFontOfSize:(size)]
#define SQBoldFont(size)  [UIFont boldSystemFontOfSize:(size)]
#define SQScaleFont(size) [UIFont systemFontOfSize:(size)*[UIScreen mainScreen].bounds.size.width / 320.0f]

#define kScreenBounds [UIScreen mainScreen].bounds
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
#define kScreenWidth  [UIScreen mainScreen].bounds.size.width

#define kSpace (8)
#define kStateBarLenngth (20)
#define kNavigationBarLength (44)
#define kNavigationLength (64)
#define kTabbarLength (49)

#define kScaleLength(length) (length) * [UIScreen mainScreen].bounds.size.width / 320.0f

#define iOS7  [[UIDevice currentDevice]systemVersion].floatValue >= 7.0
#define iOS8  [[UIDevice currentDevice]systemVersion].floatValue >= 8.0
#define iOS9  [[UIDevice currentDevice]systemVersion].floatValue >= 9.0

#ifdef DEBUG
#    define NSLog(...) SQLog(__VA_ARGS__)
#else
#define NSLog(...)
#endif

#endif
