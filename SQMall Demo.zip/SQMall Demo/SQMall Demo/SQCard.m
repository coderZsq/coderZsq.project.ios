//
//  SQCard.m
//
//  Created by Doubles_Z on 15/9/5.
//  Copyright (c) 2015年 Doubles_Z. All rights reserved.
//

#import "SQCard.h"

@interface SQCard ()

@property (nonatomic,strong) UITextView * textView;

@end

@implementation SQCard

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        [self initializeSubviews];
    }
    return self;
}

- (UIView *)contentView {
    
    if (!_contentView) {
        _contentView = [UIView new];
        _contentView.backgroundColor = [UIColor whiteColor];
        _contentView.layer.cornerRadius = 4;
        _contentView.layer.masksToBounds = YES;
        [_contentView addSubview:self.textView];
    }
    return _contentView;
}

- (UITextView *)textView {
    
    if (!_textView) {
        _textView = [UITextView new];
        _textView.text = @"uilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,euilegbfabvfbahvalbevhbhlbvahjbvhjae,bvhjabehyflbvreab,vhj,bvhrzulbhvbajh,e";
    }
    return _textView;
}

- (void)initializeSubviews {
    [self addSubview:self.contentView];

    // costom view in here
    
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.contentView.bounds = (CGRect){CGPointZero,self.width,self.width * 1};
    self.contentView.center = (CGPoint){self.width * 0.5f,self.height * 0.5};
    
    CGFloat textViewX = 0;
    CGFloat textViewY = 10;
    CGFloat textViewW = self.width;
    CGFloat textViewH = 200;
    self.textView.frame = CGRectMake(textViewX, textViewY, textViewW, textViewH);
}

@end
