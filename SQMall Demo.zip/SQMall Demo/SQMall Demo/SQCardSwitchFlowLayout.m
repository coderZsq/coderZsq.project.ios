//
//  SQCardSwitchFlowLayout.m
//
//  Created by Doubles_Z on 15/9/5.
//  Copyright (c) 2015年 Doubles_Z. All rights reserved.
//

#import "SQCardSwitchFlowLayout.h"

@implementation SQCardSwitchFlowLayout

#define ACTIVE_DISTANCE 200
#define ZOOM_FACTOR     0.3

- (void)prepareLayout {
    
    self.itemSize           = self.cellSize;
    self.scrollDirection    = UICollectionViewScrollDirectionHorizontal;
    self.sectionInset       = UIEdgeInsetsMake(200, 50, 200, 50);
    self.minimumLineSpacing = 0.0f;
}

- (BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)oldBounds {
    return YES;
}

- (NSArray*)layoutAttributesForElementsInRect:(CGRect)rect {

    NSArray * attributesArr = [super layoutAttributesForElementsInRect:rect];
    
    CGRect visibleRect;
    visibleRect.origin = self.collectionView.contentOffset;
    visibleRect.size   = self.collectionView.bounds.size;
    
    for (UICollectionViewLayoutAttributes * attributes in attributesArr) {
        CGFloat distance = CGRectGetMidX(visibleRect) - attributes.center.x;
        if (CGRectIntersectsRect(attributes.frame, rect)) {
            
            CGFloat normalizedDistance = distance / ACTIVE_DISTANCE;
            
            if (ABS(distance) < ACTIVE_DISTANCE) {
            
                CGFloat zoom = SQAngle(self.cellAngle) * normalizedDistance;
                CATransform3D transfrom = CATransform3DIdentity;
                transfrom.m34 = 1.0f / 600;
                transfrom = CATransform3DRotate(transfrom, -zoom, 0.0f, 1.0f, 0.0f);
                attributes.transform3D = transfrom;
                attributes.zIndex = 1;
            
            } else {
                
                CATransform3D transfrom = CATransform3DIdentity;
                transfrom.m34 = 1.0f / 600;
                
                if (distance > 0) {
                    transfrom = CATransform3DRotate(transfrom, -SQAngle(self.cellAngle), 0.0f, 1.0f, 0.0f);
                } else {
                    transfrom = CATransform3DRotate(transfrom,  SQAngle(self.cellAngle), 0.0f, 1.0f, 0.0f);
                }
                
                attributes.transform3D = transfrom;
                attributes.zIndex = 1;
            }
        }
    }
    return attributesArr;
}

- (CGPoint)targetContentOffsetForProposedContentOffset:(CGPoint)proposedContentOffset withScrollingVelocity:(CGPoint)velocity {
   
    CGFloat offsetAdjustment = MAXFLOAT;
    CGFloat horizontalCenter = proposedContentOffset.x + (CGRectGetWidth(self.collectionView.bounds) * 0.5f);
    CGRect targetRect        = CGRectMake(proposedContentOffset.x, 0, self.collectionView.bounds.size.width, self.collectionView.bounds.size.height);

    NSArray * attributesArr = [super layoutAttributesForElementsInRect:targetRect];
    
    for (UICollectionViewLayoutAttributes * attributes in attributesArr) {
        CGFloat itemHorizontal_X = attributes.center.x;
        if (ABS(itemHorizontal_X - horizontalCenter) < ABS(offsetAdjustment)) {
            offsetAdjustment = itemHorizontal_X - horizontalCenter;
        }
    }
    return CGPointMake(proposedContentOffset.x + offsetAdjustment, proposedContentOffset.y);
}

@end
