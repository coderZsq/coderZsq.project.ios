//
//  HYVerifyPhoneView.h
//  Mall
//
//  Created by 双泉 朱 on 15/11/10.
//  Copyright © 2015年 _Zhizi_. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HYVerifyPhoneView : UIView

@end
