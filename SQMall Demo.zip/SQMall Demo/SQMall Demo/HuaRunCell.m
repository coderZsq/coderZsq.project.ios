//
//  HuaRunCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 16/1/15.
//  Copyright © 2016年 Castiel. All rights reserved.
//

#import "HuaRunCell.h"

@interface HuaRunCell ()

@property (nonatomic,strong) UILabel * label;
@property (nonatomic,strong) CALayer * btn;

@end

@implementation HuaRunCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    NSString * identifier = NSStringFromClass([HuaRunCell class]);
    HuaRunCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[HuaRunCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self setupSubviews];
        [self.layer setShouldRasterize:YES];
        [self.layer setRasterizationScale:[UIScreen mainScreen].scale];
    }
    return self;
}

- (CALayer *)btn {
    
    if (!_btn) {
        _btn = [CALayer layer];
        _btn.contents = (__bridge id)[UIImage imageNamed:@"gesture_node_highlighted"].CGImage;
    }
    return _btn;
}

- (UILabel *)label {
    
    if (!_label) {
        _label = [UILabel new];
        _label.backgroundColor = [UIColor whiteColor];
//        _label.
        _label.text = @"text text text text text text ";
    }
    return _label;
}

- (void)setupSubviews {
    [self.contentView addSubview:self.label];
    [self.contentView.layer addSublayer:self.btn];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.label.frame = CGRectMake(100, 0, 200, 100);
    self.btn.frame = CGRectMake(0, 0, 74, 74);
}

@end
