//
//  SQInfiniteLoopCell.h
//
//  Created by Doubles_Z on 15/9/5.
//  Copyright (c) 2015年 Doubles_Z. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SQInfiniteLoopCell : UITableViewCell

@property (nonatomic,strong) NSArray * infiniteLoopData;

@property (nonatomic,assign) NSTimeInterval timeInterval;

@property (nonatomic,strong) UIColor * pageIndicatorTintColor;

@property (nonatomic,strong) UIColor * currentPageIndicatorTintColor;

@property (nonatomic) CGFloat cellHeight;

+ (instancetype)cellWithTableView:(UITableView *)tableView;

@end
