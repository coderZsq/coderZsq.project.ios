//
//  HuaRunCell.h
//  SQMall Demo
//
//  Created by 双泉 朱 on 16/1/15.
//  Copyright © 2016年 Castiel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HuaRunCell : UITableViewCell

+ (instancetype)cellWithTableView:(UITableView *)tableView;

@end
