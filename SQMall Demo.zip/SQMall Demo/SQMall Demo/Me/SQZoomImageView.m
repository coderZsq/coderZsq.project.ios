//
//  SQZoomImageView.m
//
//  Created by Doubles_Z on 15/9/5.
//  Copyright (c) 2015年 Doubles_Z. All rights reserved.
//

#import "SQZoomImageView.h"
#import "SQZoomTableHeaderView.h"

@interface SQZoomImageView ()

@property (nonatomic,strong) SQZoomTableHeaderView * tableHeaderView;

@end

@implementation SQZoomImageView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        [self setupStatus];
    }
    return self;
}

- (void)setupStatus {
    CGFloat screenWidth    = [UIScreen mainScreen].bounds.size.width;
    self.bounds            = (CGRect) {CGPointZero,screenWidth,screenWidth};
    self.layer.position    = (CGPoint){screenWidth * 0.5f, - screenWidth * 0.25f};
    self.layer.anchorPoint = (CGPoint){0.5f, 0};
}

- (SQZoomTableHeaderView *)tableHeaderView {
    
    if (!_tableHeaderView) {
        _tableHeaderView = [SQZoomTableHeaderView new];
    }
    return _tableHeaderView;
}

- (void)setTableView:(UITableView *)tableView {
    _tableView = tableView;
    [tableView insertSubview:self atIndex:0];
    [tableView setTableHeaderView:self.tableHeaderView];
}

- (void)zoomingWithOffset:(CGPoint)offset {
    
    CGFloat offset_y = offset.y; if (offset_y > 0) return;
    CGFloat point    = - (self.frame.size.height / 6) / (1 - 0.5f);
    
    if (offset_y >= point) {
        self.transform = CGAffineTransformMakeTranslation(0, offset_y * 0.5f);
    } else {
        CGAffineTransform transform = CGAffineTransformMakeTranslation(0, offset_y - point * (1 - 0.5f));
        CGFloat scale = 1 + (point - offset_y) * 0.005f;
        self.transform = CGAffineTransformScale(transform, scale, scale);
    }
}

@end
