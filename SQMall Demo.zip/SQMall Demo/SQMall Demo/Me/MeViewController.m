//
//  MeViewController.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/10.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "MeViewController.h"
#import "SQScaleImageView.h"

@interface MeViewController ()

@property (nonatomic,strong) SQScaleImageView * imageView;
@end

@implementation MeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationController.navigationBar.hidden = YES;
    self.imageView.tableView = self.tableView;
}

- (SQScaleImageView *)imageView {
    
    if (!_imageView) {
        _imageView = [SQScaleImageView new];
        _imageView.image = [UIImage imageNamed:@"shoupin"];
    }
    return _imageView;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    NSLog(@"%f",scrollView.contentOffset.y);
    [self.imageView scaleWithScrollViewContentOffset:scrollView.contentOffset];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 20;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    UITableViewCell *  nn = [UITableViewCell new];
    nn.textLabel.text = [NSString stringWithFormat:@"%li",indexPath.row];
    return nn;
}

@end