//
//  UIButton+SQExtension.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 16/1/12.
//  Copyright © 2016年 Castiel. All rights reserved.
//

#import "UIButton+SQExtension.h"

@implementation UIButton (SQExtension)

- (void)whenTouchUpInside:(SQWhenTouchedBlock)block {
    [self addTarget:self action:@selector(touchUpInside) forControlEvents:UIControlEventTouchUpInside];

}

@end
