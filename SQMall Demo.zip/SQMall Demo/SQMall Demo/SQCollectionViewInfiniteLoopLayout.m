//
//  SQCollectionViewInfiniteLoopLayout.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 16/2/4.
//  Copyright © 2016年 Castiel. All rights reserved.
//

#import "SQCollectionViewInfiniteLoopLayout.h"

@interface SQCollectionViewInfiniteLoopLayout ()

@property (nonatomic,strong) NSMutableArray * visibleCountArr;
@property (nonatomic,assign,getter = isFirstEnter) BOOL firstEnter;

@end

@implementation SQCollectionViewInfiniteLoopLayout

- (instancetype)init {
    
    self = [super init];
    if (self) {
        self.firstEnter = YES;
    }
    return self;
}

- (void)prepareLayout {
    [super prepareLayout];
    
    if (self.isFirstEnter) {
        self.collectionView.contentOffset = CGPointMake(self.collectionView.frame.size.width, self.collectionView.contentOffset.y);
        self.collectionView.pagingEnabled = YES;
    } self.firstEnter = NO;
}

- (UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CGFloat layoutAttributeY = self.collectionView.contentOffset.y;
    CGFloat layoutAttributeW = self.collectionView.frame.size.width;
    CGFloat layoutAttributeH = self.collectionView.frame.size.height;
    CGFloat layoutAttributeX = layoutAttributeW * (indexPath.item + 1);
    
    CGRect visibleRect;
    visibleRect.size   = self.collectionView.frame.size;
    visibleRect.origin = self.collectionView.contentOffset;
    
    UICollectionViewLayoutAttributes * layoutAttribute = [UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
    
    
    
    layoutAttribute.frame = CGRectMake(layoutAttributeX,
                                       layoutAttributeY,
                                       layoutAttributeW,
                                       layoutAttributeH);
    
    return layoutAttribute;
}

- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect {

    NSMutableArray * layoutAttributesArr = [NSMutableArray array];
    NSInteger count = [self.collectionView numberOfItemsInSection:0];
    for (int i = 0; i < count; i++) {
        [layoutAttributesArr addObject:[self layoutAttributesForItemAtIndexPath:[NSIndexPath indexPathForItem:i inSection:0]]];
    }
    return layoutAttributesArr;
}

- (BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds {
    return YES;
}

- (CGSize)collectionViewContentSize {
    return CGSizeMake(3 * self.collectionView.frame.size.width ,0);
}


@end
