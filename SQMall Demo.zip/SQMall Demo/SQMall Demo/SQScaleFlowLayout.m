//
//  SQScaleFlowLayout.m
//
//  Created by Doubles_Z on 15/9/5.
//  Copyright (c) 2015年 Doubles_Z. All rights reserved.
//

#import "SQScaleFlowLayout.h"

@implementation SQScaleFlowLayout

static CGFloat const itemWH         = 100;
static CGFloat const activeDistance = 150;
static CGFloat const scaleFactor    = 0.6;
static CGFloat const spaceFactor    = 0.5;

- (void)prepareLayout {
    
    [super prepareLayout];
    
    self.itemSize = CGSizeMake(itemWH, itemWH);
    CGFloat inset = (self.collectionView.frame.size.width - itemWH) * 0.5;
    self.sectionInset = UIEdgeInsetsMake(0, inset, 0, inset);
    self.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    self.minimumLineSpacing = itemWH * spaceFactor;
}

- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect {
    
    CGRect visibleRect;
    visibleRect.size   = self.collectionView.frame.size;
    visibleRect.origin = self.collectionView.contentOffset;
    
    NSArray * layoutAttributesArr = [super layoutAttributesForElementsInRect:rect];
    
    CGFloat centerX = self.collectionView.contentOffset.x + self.collectionView.frame.size.width * 0.5;
    
    for (UICollectionViewLayoutAttributes * layoutAttribute in layoutAttributesArr) {
        if (!CGRectIntersectsRect(visibleRect, layoutAttribute.frame)) continue;
        CGFloat itemCenterX = layoutAttribute.center.x;
        CGFloat scale = 1 + scaleFactor * (1 - (ABS(itemCenterX - centerX) / activeDistance));
        layoutAttribute.transform = CGAffineTransformMakeScale(scale, scale);
    }
    
    return layoutAttributesArr;
}

- (BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds {
    return YES;
}

- (CGPoint)targetContentOffsetForProposedContentOffset:(CGPoint)proposedContentOffset withScrollingVelocity:(CGPoint)velocity {
    
    CGRect lastRect;
    lastRect.size   = self.collectionView.frame.size;
    lastRect.origin = proposedContentOffset;
    
    CGFloat centerX = proposedContentOffset.x + self.collectionView.frame.size.width * 0.5;
    
    NSArray * layoutAttributesArr = [self layoutAttributesForElementsInRect:lastRect];
    
    CGFloat adjustOffsetX = MAXFLOAT;
    for (UICollectionViewLayoutAttributes * layoutAttribute in layoutAttributesArr) {
        if (ABS(layoutAttribute.center.x - centerX) < ABS(adjustOffsetX)) {
            adjustOffsetX = layoutAttribute.center.x - centerX;
        }
    }
    
    return CGPointMake(proposedContentOffset.x + adjustOffsetX, proposedContentOffset.y);
}

@end
