//
//  SQCollectionViewCell.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/12/29.
//  Copyright © 2015年 Castiel. All rights reserved.
//

#import "SQCollectionViewCell.h"

@interface SQCollectionViewCell ()
@property (nonatomic,strong) UITextView * scaleView;

@end

@implementation SQCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    if (self) {
        [self.contentView addSubview:self.scaleView];
    }
    return self;
}

- (UIView *)scaleView {
    
    if (!_scaleView) {
        _scaleView = [UITextView new];
        _scaleView.backgroundColor = [UIColor whiteColor];
        _scaleView.layer.cornerRadius = 6;
        _scaleView.layer.masksToBounds = YES;
        _scaleView.text = @"djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,djuilfclvcbjhwbchjbchjwLV,JBELFVCFVVB,RVVR,VFJ,";
    }
    return _scaleView;
}

- (void)layoutSubviews {
    self.scaleView.frame = self.bounds;
}

@end
