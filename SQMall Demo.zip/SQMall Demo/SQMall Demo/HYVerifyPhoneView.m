//
//  HYVerifyPhoneView.m
//  Mall
//
//  Created by 双泉 朱 on 15/11/10.
//  Copyright © 2015年 _Zhizi_. All rights reserved.
//

#import "HYVerifyPhoneView.h"
//#import "HYUIViewController.h"
//#import <HYUserSender.h>
#import "CAAnimation+SQExtension.h"
#import "NSString+SQExtension.h"

#define WinSize     [UIScreen mainScreen].bounds.size
#define Color(r,g,b)[UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:1.0f]
#define Font(x)     [UIFont systemFontOfSize:x]
#define kscaleDeviceLength(length) (length * WinSize.width)/320.0f

@interface HYVerifyPhoneView () <UITextFieldDelegate>

//@property (nonatomic,strong) HYUIViewController * viewController;

@property (nonatomic,strong) UIView      * contentView;
@property (nonatomic,strong) UIView      * verifyView;
@property (nonatomic,strong) UIView      * phoneNumberView;
@property (nonatomic,strong) UIView      * verifyCodeView;

@property (nonatomic,strong) UITextField * phoneNumber;
@property (nonatomic,strong) UITextField * verifyCode;

@property (nonatomic,strong) UIButton    * backgroundButton;
@property (nonatomic,strong) UIButton    * exitButton;
@property (nonatomic,strong) UIButton    * verifyButton;
@property (nonatomic,strong) UIButton    * confirmButton;

@property (nonatomic,strong) UILabel     * titleLabel;
@property (nonatomic,strong) UILabel     * subTitleLabel;
@property (nonatomic,strong) UILabel     * phoneLabel;
@property (nonatomic,strong) UILabel     * verifyLabel;
@property (nonatomic,strong) UILabel     * toastLabel;

@property (nonatomic,strong) UIImageView * loadImageView;

@property (nonatomic,strong) NSTimer     * timer;
@property (nonatomic,assign) NSInteger     second;

@property (nonatomic,assign,getter = isRequset) BOOL request;

@end

@implementation HYVerifyPhoneView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        [self prepareForInitialize];
        [self initializeSubviews];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    
    self = [super initWithCoder:coder];
    if (self) {
        [self prepareForInitialize];
        [self initializeSubviews];
    }
    return self;
}

//- (HYUIViewController *)viewController {
//    
//    if (!_viewController) {
//        _viewController =  [HYUIViewController new];
//    }
//    return _viewController;
//}

#pragma mark - Request
- (void)userBindVerifyCodeRequset {
    
//    self.request = YES;
//    HYUserSessionCacheBean * cachebean = [HYUserSessionCacheBean sharedInstance];
//    HYSenderResultModel * resultModel = [HYUserSender senderUserBindVerifyCode:cachebean phone:_self.phoneNumber.text];
//    [self startLoading];
//    [self.viewController requestWithModel:resultModel success:^(HYResponseModel *model) {
//        [self.phoneLabel setText:@"验证短信发送成功请查收!"];
//        [self.verifyCode setUserInteractionEnabled:YES];
//        [self setupTimer];
//        [self endLoading];
//    } failure:^(HYResponseModel * model) {
//        [self phoneVerifyError:cachebean.msgBindVerifyCode error:nil];
//        [self endLoading];
//    }];
}

- (void)userBindPhoneRequset {
    
//    self.request = YES;
//    HYUserSessionCacheBean * cachebean = [HYUserSessionCacheBean sharedInstance];
//    HYSenderResultModel * resultModel = [HYUserSender senderUserBindPhone:cachebean phone:_self.phoneNumber.text verifyCode:_self.verifyCode.text];
//    [self startLoading];
//    [self.viewController requestWithModel:resultModel success:^(HYResponseModel *model) {
//        [self endLoading];
//        [self makeToast];
//    } failure:^(HYResponseModel * model) {
//        [self phoneVerifyError:nil error:cachebean.msgBindPhone];
//        [self endLoading];
//    }];
}

#pragma mark - Loading
- (void)startLoading {
    
    if (!self.loadImageView) {
        UIImage *image = [UIImage imageNamed:@"pay_loading"];
        self.loadImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
        self.loadImageView.center = CGPointMake(WinSize.width * 0.5f, self.frame.size.height * 0.5f);
        [self.loadImageView setImage:image];
        [self addSubview:self.loadImageView];
    }   self.loadImageView.hidden = NO;
    if (self.loadImageView && !self.loadImageView.hidden) {
        [self rotateAnimation];
    }
}

- (void)endLoading {
    [self.loadImageView.layer removeAnimationForKey:@"rotate"]; self.loadImageView.hidden = YES;
}

#pragma mark - PrepareForInitialize
- (void)prepareForInitialize {
    [self setFrame:[UIScreen mainScreen].bounds];
    [self setAlpha:0.0f];
    [self setupNotificationCenter];
    [self setupEnterAnimation];
}

- (void)setupNotificationCenter {
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillChangeFrame:)
                                                 name:UIKeyboardWillChangeFrameNotification object:nil];
}

- (void)removeNotificationCenter {
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

- (void)keyboardWillChangeFrame:(NSNotification *)notification {
    
    self.window.backgroundColor = self.backgroundColor;
    CGFloat duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    CGRect keyboardFrame = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGFloat transformY = keyboardFrame.origin.y - self.frame.size.height;
    [UIView animateWithDuration:duration animations:^{
        self.transform = CGAffineTransformMakeTranslation(0, transformY * 0.4f);
    }];
}

- (void)exitKeyBoard {
    [self endEditing:YES];
}

- (void)setupEnterAnimation {
    [UIView animateWithDuration:0.25f animations:^{
        self.alpha = 1.0f;
    }];
}

#pragma mark - InitializeSubviews
- (void)initializeSubviews {
    [self addSubview:self.backgroundButton];
    [self addSubview:self.contentView];
    [self addSubview:self.toastLabel];
}

- (UIView *)contentView {
    
    if (!_contentView) {
        _contentView = [UIView new];
        _contentView.backgroundColor = Color(245, 245, 245);
        _contentView.layer.cornerRadius = 4;
        _contentView.layer.masksToBounds = YES;
        [_contentView addSubview:self.titleLabel];
        [_contentView addSubview:self.exitButton];
        [_contentView addSubview:self.subTitleLabel];
        [_contentView addSubview:self.verifyView];
        [_contentView addSubview:self.confirmButton];
    }
    return _contentView;
}

- (UIView *)verifyView {
    
    if (!_verifyView) {
        _verifyView = [UIView new];
        [_verifyView addSubview:self.phoneNumberView];
        [_verifyView addSubview:self.phoneLabel];
        [_verifyView addSubview:self.verifyCodeView];
        [_verifyView addSubview:self.verifyLabel];
        [_verifyView addSubview:self.verifyButton];
    }
    return _verifyView;
}

- (UIView *)phoneNumberView {
    
    if (!_phoneNumberView) {
        _phoneNumberView = [UIView new];
        _phoneNumberView.backgroundColor = [UIColor whiteColor];
        [_phoneNumberView addSubview:self.phoneNumber];
    }
    return _phoneNumberView;
}

- (UIView *)verifyCodeView {
    
    if (!_verifyCodeView) {
        _verifyCodeView = [UIView new];
        _verifyCodeView.backgroundColor = [UIColor whiteColor];
        [_verifyCodeView addSubview:self.verifyCode];
    }
    return _verifyCodeView;
}

- (UIButton *)backgroundButton {
    
    if (!_backgroundButton) {
        _backgroundButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _backgroundButton.adjustsImageWhenHighlighted = NO;
        _backgroundButton.backgroundColor = [UIColor blackColor];
        [_backgroundButton addTarget:self action:@selector(exitKeyBoard) forControlEvents:UIControlEventTouchUpInside];
        _backgroundButton.alpha = 0.7f;
    }
    return _backgroundButton;
}

- (UIButton *)exitButton {
    
    if (!_exitButton) {
        _exitButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_exitButton setImage:[UIImage imageNamed:@"icon_detel"] forState:UIControlStateNormal];
        [_exitButton addTarget:self action:@selector(removeAllObjects) forControlEvents:UIControlEventTouchUpInside];
    }
    return _exitButton;
}

- (UIButton *)verifyButton {
    
    if (!_verifyButton) {
        _verifyButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_verifyButton setTitle:@"获取验证码" forState:0];
        [_verifyButton setTitleColor:self.subTitleLabel.textColor forState:0];
        [_verifyButton addTarget:self action:@selector(verifyButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        _verifyButton.titleLabel.font = [UIFont systemFontOfSize:15];
        _verifyButton.backgroundColor = [UIColor whiteColor];
        _verifyButton.layer.borderWidth = 1.f;
        _verifyButton.layer.borderColor = [UIColor grayColor].CGColor;
    }
    return _verifyButton;
}

- (UIButton *)confirmButton {
    
    if (!_confirmButton) {
        _confirmButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_confirmButton setTitle:@"确认" forState:0];
        [_confirmButton setTitleColor:[UIColor whiteColor] forState:0];
        _confirmButton.backgroundColor = self.subTitleLabel.textColor;
        [_confirmButton addTarget:self action:@selector(confirmButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _confirmButton;
}

- (UITextField *)phoneNumber {
    
    if (!_phoneNumber) {
        _phoneNumber = [UITextField new];
        _phoneNumber.placeholder = @"请输入手机号";
        _phoneNumber.font = Font(14);
        _phoneNumber.delegate = self;
        _phoneNumber.keyboardType = UIKeyboardTypeNumberPad;
        _phoneNumber.clearButtonMode = UITextFieldViewModeWhileEditing;
        [_phoneNumber setValue:[UIColor lightGrayColor] forKeyPath:@"placeholderLabel.textColor"];
    }
    return _phoneNumber;
}

- (UITextField *)verifyCode {
    
    if (!_verifyCode) {
        _verifyCode = [UITextField new];
        _verifyCode.placeholder = @"请输入验证码";
        _verifyCode.font = Font(14);
        _verifyCode.delegate = self;
        _verifyCode.clearButtonMode = UITextFieldViewModeWhileEditing;
        _verifyCode.userInteractionEnabled = NO;
        [_verifyCode setValue:[UIColor lightGrayColor] forKeyPath:@"placeholderLabel.textColor"];
    }
    return _verifyCode;
}

- (UILabel *)titleLabel {
    
    if (!_titleLabel) {
        _titleLabel = [UILabel new];
        _titleLabel.text = @"\n验证手机";
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.numberOfLines = 2;
    }
    return _titleLabel;
}

- (UILabel *)subTitleLabel {
    
    if (!_subTitleLabel) {
        _subTitleLabel = [UILabel new];
        _subTitleLabel.text = @"为了您的账户安全,现在需要验证您的手机号码,通过验证之后还有送积分哦,积分直接当钱使用!";
        _subTitleLabel.font = Font(12);
        _subTitleLabel.textColor = Color(196,62,76);
        _subTitleLabel.numberOfLines = 2;
        _subTitleLabel.adjustsFontSizeToFitWidth = YES;
    }
    return _subTitleLabel;
}

- (UILabel *)phoneLabel {
    
    if (!_phoneLabel) {
        _phoneLabel = [UILabel new];
        _phoneLabel.textColor = self.subTitleLabel.textColor;
        _phoneLabel.font = Font(10);
    }
    return _phoneLabel;
}

- (UILabel *)verifyLabel {
    
    if (!_verifyLabel) {
        _verifyLabel = [UILabel new];
        _verifyLabel.textColor = self.subTitleLabel.textColor;
        _verifyLabel.font = self.phoneLabel.font;
    }
    return _verifyLabel;
}

- (UILabel *)toastLabel {
    
    if (!_toastLabel) {
        _toastLabel = [UILabel new];
        _toastLabel.bounds = CGRectMake(0, 0, 100, 30);
        _toastLabel.center = [UIApplication sharedApplication].keyWindow.center;
        _toastLabel.backgroundColor = [UIColor blackColor];
        _toastLabel.textColor = [UIColor whiteColor];
        _toastLabel.textAlignment = NSTextAlignmentCenter;
        _toastLabel.layer.cornerRadius = 6;
        _toastLabel.layer.masksToBounds = YES;
        _toastLabel.text = @"手机号验证成功";
        _toastLabel.alpha = 0.0f;
        _toastLabel.font = Font(11);
    }
    return _toastLabel;
}

#pragma mark - LayoutSubviews
- (void)layoutSubviews {
    [super layoutSubviews];
    self.backgroundButton.frame = [UIScreen mainScreen].bounds;
    self.contentView.bounds = CGRectMake(0, 0, kscaleDeviceLength(270), kscaleDeviceLength(240));
    self.contentView.center = CGPointMake(WinSize.width * 0.5f,  WinSize.height* 0.5f - kscaleDeviceLength(20));
    [self layoutContentView];
}

//static const double kSpace = 8;

- (void)layoutContentView {
    
    CGFloat titleLabelX = 0;
    CGFloat titleLabelY = 0;
    CGFloat titleLabelW = self.contentView.frame.size.width;
    CGFloat titleLabelH = kscaleDeviceLength(50);
    self.titleLabel.frame = CGRectMake(titleLabelX, titleLabelY, titleLabelW, titleLabelH);
    
    CGFloat exitButtonW = 25;
    CGFloat exitButtonX = self.contentView.frame.size.width - exitButtonW - kSpace;
    CGFloat exitButtonY = kSpace;
    CGFloat exitButtonH = exitButtonW;
    self.exitButton.frame = CGRectMake(exitButtonX, exitButtonY, exitButtonW, exitButtonH);
    
    CGFloat subTitleLabelX = titleLabelX + 20;
    CGFloat subTitleLabelY = titleLabelY + titleLabelH;
    CGFloat subTitleLabelW = titleLabelW - 40;
    CGFloat subTitleLabelH = kscaleDeviceLength(40);
    self.subTitleLabel.frame = CGRectMake(subTitleLabelX, subTitleLabelY, subTitleLabelW, subTitleLabelH);
    
    CGFloat verifyViewX = titleLabelX;
    CGFloat verifyViewY = subTitleLabelY + subTitleLabelH;
    CGFloat verifyViewW = titleLabelW;
    CGFloat verifyViewH = kscaleDeviceLength(100);
    self.verifyView.frame = CGRectMake(verifyViewX, verifyViewY, verifyViewW, verifyViewH);
    
    [self layoutVerifyView];
    
    CGFloat confirmButtonH = kscaleDeviceLength(40);
    CGFloat confirmButtonX = titleLabelX;
    CGFloat confirmButtonY = self.contentView.frame.size.height - confirmButtonH;
    CGFloat confirmButtonW = self.contentView.frame.size.width;
    self.confirmButton.frame = CGRectMake(confirmButtonX, confirmButtonY, confirmButtonW, confirmButtonH);
}

- (void)layoutVerifyView {
    
    CGFloat phoneNumberViewX = CGRectGetMinX(self.subTitleLabel.frame);
    CGFloat phoneNumberViewY = kSpace * 1.5f;
    CGFloat phoneNumberViewW = self.subTitleLabel.frame.size.width;
    CGFloat phoneNumberViewH = kscaleDeviceLength(30);
    self.phoneNumberView.frame = CGRectMake(phoneNumberViewX, phoneNumberViewY, phoneNumberViewW, phoneNumberViewH);
    
    CGFloat phoneNumberX = kSpace;
    CGFloat phoneNumberY = 0;
    CGFloat phoneNumberW = phoneNumberViewW - kSpace;
    CGFloat phoneNumberH = phoneNumberViewH;
    self.phoneNumber.frame = CGRectMake(phoneNumberX, phoneNumberY, phoneNumberW, phoneNumberH);
    
    CGFloat phoneLabelX = phoneNumberViewX + kSpace;
    CGFloat phoneLabelY = phoneNumberViewY + phoneNumberViewH;
    CGFloat phoneLabelW = phoneNumberViewW;
    CGFloat phoneLabelH = kscaleDeviceLength(20);
    self.phoneLabel.frame = CGRectMake(phoneLabelX, phoneLabelY, phoneLabelW, phoneLabelH);
    
    CGFloat verifyCodeViewX = phoneNumberViewX;
    CGFloat verifyCodeViewY = phoneNumberViewY + phoneNumberViewH + phoneLabelH;
    CGFloat verifyCodeViewW = phoneNumberViewW * 0.5f + kSpace;
    CGFloat verifyCodeViewH = phoneNumberViewH;
    self.verifyCodeView.frame = CGRectMake(verifyCodeViewX, verifyCodeViewY, verifyCodeViewW, verifyCodeViewH);
    
    CGFloat verifyCodeX = kSpace;
    CGFloat verifyCodeY = 0;
    CGFloat verifyCodeW = verifyCodeViewW - kSpace;
    CGFloat verifyCodeH = verifyCodeViewH;
    self.verifyCode.frame = CGRectMake(verifyCodeX, verifyCodeY, verifyCodeW, verifyCodeH);
    
    CGFloat verifyLabelX = phoneLabelX;
    CGFloat verifyLabelY = verifyCodeViewY + verifyCodeH;
    CGFloat verifyLabelW = phoneLabelW;
    CGFloat verifyLabelH = phoneLabelH;
    self.verifyLabel.frame = CGRectMake(verifyLabelX, verifyLabelY, verifyLabelW, verifyLabelH);
    
    CGFloat verifyButtonY = verifyCodeViewY;
    CGFloat verifyButtonW = phoneNumberViewW - verifyCodeViewW - kSpace;
    CGFloat verifyButtonX = verifyCodeViewW + kSpace + phoneNumberViewX;
    CGFloat verifyButtonH = verifyCodeViewH;
    self.verifyButton.frame = CGRectMake(verifyButtonX, verifyButtonY, verifyButtonW, verifyButtonH);
}

#pragma mark - UITextField delegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    if (textField == self.phoneNumber) {
        if (textField.text.length + 1 > 11) {
            textField.text = [textField.text substringToIndex:string.length ? textField.text.length - 1 : textField.text.length];
        }   if (textField.text.length) self.phoneLabel.text = nil; self.verifyLabel.text = nil;
    }
    if (textField == self.verifyCode) {
        if (textField.text.length + 1 > 6) {
            textField.text = [textField.text substringToIndex:string.length ? textField.text.length - 1 : textField.text.length];
        }   if (textField.text.length) self.verifyLabel.text = nil;
    }
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
    if (textField == self.phoneNumber) self.phoneLabel.text = nil;
    if (textField == self.verifyCode) self.verifyLabel.text = nil;
    return YES;
}

#pragma mark - Button click events
- (void)verifyButtonClick:(UIButton *)sender {
    
    self.request = NO;
    if ([self.phoneNumber.text isValidateMobile]) {
        [self setSecond:0]; [self userBindVerifyCodeRequset];
    } else  [self phoneEnterError];
}

- (void)confirmButtonClick:(UIButton *)sender {
    [self makeToast]; return;
    if (!self.verifyCode.userInteractionEnabled) {
        [self phoneEnterError];
        [self verifyEnterError];
        return;
    }   [self userBindPhoneRequset];
}

#pragma mark - Validate mobile
- (BOOL)isValidateMobile:(NSString *)mobile {
    
    NSString *phoneRegex = @"^[1][0-9]{10}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex];
    return [phoneTest evaluateWithObject:mobile];
}

#pragma mark - CountDown timer
- (void)setupTimer {
    self.timer = [NSTimer timerWithTimeInterval:1.0f target:self selector:@selector(countDown) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
}

- (NSInteger)second {
    
    if (_second == 0) {
        _second = 60;
    }
    return _second;
}

- (void)countDown {
    
    if (self.second == 1) {
        [self.timer invalidate];
        [self.verifyButton setEnabled:YES];
        [self.verifyButton setTitle:@"重发验证码" forState:0];
        return;
    }   self.second--; [self updateWithTimer];
}

- (void)updateWithTimer {
    [_verifyButton setTitle:[NSString stringWithFormat:@"%li秒后重发",self.second] forState:0];
    [_verifyButton.titleLabel setFont:Font(13)];
    [_verifyButton setTitleColor:[UIColor grayColor] forState:0];
    [_verifyButton setEnabled:NO];
}

#pragma mark - Error infomation
- (void)phoneEnterError {
    self.phoneLabel.text = @"手机号码错误!";
    [self shakeAnimation];
}

- (void)verifyEnterError {
    self.verifyLabel.text = @"验证码错误!";
    [self shakeAnimation];
}

- (void)phoneVerifyError:(NSString *)msgBindVerifyCode error:(NSString *)msgBindPhone {
    self.phoneLabel.text  = msgBindVerifyCode; self.verifyLabel.text = msgBindPhone;
    [self shakeAnimation];
}

#pragma mark - Animation
- (void)shakeAnimation {
    
    CGFloat sec = self.isRequset ? 0.15f : 0.0f;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [CAAnimation animationShakeWithLayer:self.contentView.layer xy:@"x" repeatCount:1];
    });
}

- (void)rotateAnimation {
    
    CABasicAnimation* animation = [CABasicAnimation animation];
    animation.keyPath = @"transform.rotation.z";
    animation.toValue = [NSNumber numberWithFloat:((360.0f * M_PI) / 180.0f)];
    animation.duration = 2.0f;
    animation.repeatCount = MAXFLOAT;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    [self.loadImageView.layer addAnimation:animation forKey:@"rotate"];
}

- (void)toastAnimation {

    CABasicAnimation * animation = [CABasicAnimation animation];
    animation.keyPath = @"opacity";
    animation.fromValue = [NSNumber numberWithFloat:0.0];
    animation.toValue = [NSNumber numberWithFloat:1.0];
    animation.duration = 1.0f;
    animation.delegate = self;
    animation.autoreverses = YES;
    animation.removedOnCompletion = YES;
    [self.toastLabel.layer addAnimation:animation forKey:@"toast"];
}

#pragma mark - Exit
- (void)makeToast {
    [self toastAnimation];
}

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag {
    [self exitKeyBoard];
    [self removeAllObjects];
}

- (void)removeAllObjects {
    
    [UIView animateWithDuration:0.25f animations:^{
        [self setAlpha:0.0f];
        [self exitKeyBoard];
    } completion:^(BOOL finished) {
        [self removeNotificationCenter];
        [self removeFromSuperview];
    }];
}

@end
