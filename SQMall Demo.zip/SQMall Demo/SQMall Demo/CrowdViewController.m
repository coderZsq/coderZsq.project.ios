//
//  CrowdViewController.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/12/29.
//  Copyright © 2015年 Castiel. All rights reserved.
//

#import "CrowdViewController.h"
#import "LoopView.h"

@interface CrowdViewController ()

@property (nonatomic,strong) LoopView * loopView;

@end

@implementation CrowdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    LoopView * ll = [LoopView new];
    ll.frame = CGRectMake(0, 0, 100, 100);
    
    [self.view addSubview:ll];
}


@end
