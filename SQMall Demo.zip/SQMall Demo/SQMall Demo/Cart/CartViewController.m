//
//  CartViewController.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/10/10.
//  Copyright (c) 2015年 Castiel. All rights reserved.
//

#import "CartViewController.h"
#import "UIView+SQExtension.h"

@interface CartViewController ()

@property (nonatomic,strong) UIView         * containerView;
@property (nonatomic,strong) UIView         * containerView2;
@property (nonatomic,strong) UIView         * containerView3;
@property (nonatomic,strong) NSMutableArray * faces;
@property (nonatomic,strong) NSArray        * faceColors;

@end

@implementation CartViewController

- (UIView *)containerView {

    if (!_containerView) {
        _containerView = [UIView new];
        _containerView.frame = self.view.bounds;
    }
    return _containerView;
}

- (UIView *)containerView2 {

    if (!_containerView2) {
        _containerView2 = [UIView new];
        _containerView2.frame = CGRectMake(0, 0, 375, 200);
    }
    return _containerView2;
}

- (UIView *)containerView3 {
    
    if (!_containerView3) {
        _containerView3 = [UIView new];
        _containerView3.frame = CGRectMake(0, 150, 375, 400);
    }
    return _containerView3;
}

- (NSArray *)faceColors {
    
    _faceColors = @[[UIColor redColor],
                    [UIColor orangeColor],
                    [UIColor yellowColor],
                    [UIColor greenColor],
                    [UIColor cyanColor],
                    [UIColor blueColor]];
    return _faceColors;
}

- (NSMutableArray *)faces {

    _faces = @[].mutableCopy;
    for (int i = 0; i < 6; i++) {
        UIButton * face = [UIButton buttonWithType:UIButtonTypeCustom];
        face.backgroundColor = self.faceColors[i];
        face.frame = CGRectMake(0, 0, 60, 60);
        [_faces addObject:face];
    }
    return _faces;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self addCubeWith:self.containerView];
    [self addCubeWith:self.containerView2];
    [self addCubeWith:self.containerView3];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [self.view removeAllSubviews];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBarItem.badgeValue = @"nnn";
    [self.view setBackgroundColor:[UIColor lightGrayColor]];
}

- (void)addCubeWith:(UIView *)view {
    
    [self.view addSubview:view];
    
    CATransform3D transform = CATransform3DMakeTranslation(0, 0, 30);
    [view.layer addSublayer:[self addFace:1 withTransform:transform]];
    
    transform = CATransform3DMakeTranslation(30, 0, 0);
    transform = CATransform3DRotate(transform, M_PI_2, 0, 1, 0);
    [view.layer addSublayer:[self addFace:2 withTransform:transform]];
    
    transform = CATransform3DMakeTranslation(0, -30, 0);
    transform = CATransform3DRotate(transform, M_PI_2, 1, 0, 0);
    [view.layer addSublayer:[self addFace:3 withTransform:transform]];
    
    transform = CATransform3DMakeTranslation(0, 30, 0);
    transform = CATransform3DRotate(transform, -M_PI_2, 1, 0, 0);
    [view.layer addSublayer:[self addFace:4 withTransform:transform]];
    
    transform = CATransform3DMakeTranslation(-30, 0, 0);
    transform = CATransform3DRotate(transform, -M_PI_2, 0, 1, 0);
    [view.layer addSublayer:[self addFace:5 withTransform:transform]];
    
    transform = CATransform3DMakeTranslation(0, 0, -30);
    transform = CATransform3DRotate(transform, M_PI, 0, 1, 0);
    [view.layer addSublayer:[self addFace:6 withTransform:transform]];
    
    CATransform3D perspective = CATransform3DIdentity;
    perspective.m34 = -1.0 / 600.0;
    perspective = CATransform3DRotate(perspective, -M_PI_4, 1, 0, 0);
    view.layer.sublayerTransform = perspective;
    [self animationWithLayer:view.layer];
}


- (CALayer *)addFace:(NSInteger)i withTransform:(CATransform3D)transform {
    
    UIButton * face = self.faces[i - 1];
    face.center = self.containerView.center;
    face.layer.transform = transform;
    return face.layer;
}

- (void)animationWithLayer:(CALayer *)layer {
    
    CABasicAnimation * animation = [CABasicAnimation animation];
    animation.keyPath = @"sublayerTransform.rotation.y";
    animation.toValue = @(2 * M_PI);
    animation.repeatCount = INFINITY;
    animation.duration = 2;
    animation.speed = 2;
    [layer addAnimation:animation forKey:nil];
}

@end
