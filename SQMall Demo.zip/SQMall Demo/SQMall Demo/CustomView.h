//
//  CustomView.h
//
//  Code generated using QuartzCode 1.21 on 15/12/30.
//  www.quartzcodeapp.com
//

#import <UIKit/UIKit.h>

@interface CustomView : UIView


- (IBAction)startAllAnimations:(id)sender;

@end