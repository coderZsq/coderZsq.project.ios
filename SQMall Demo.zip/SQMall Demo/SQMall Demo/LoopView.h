//
//  LoopView.h
//  SQMall Demo
//
//  Created by 双泉 朱 on 16/2/4.
//  Copyright © 2016年 Castiel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoopView : UIView

@end
