//
//  SQBenifitsViewController.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 15/12/28.
//  Copyright © 2015年 Castiel. All rights reserved.
//

#import "SQBenifitsViewController.h"
#import "SQLockView.h"
#import "SQWaterwaveView.h"

@interface SQBenifitsViewController () <SQLockViewDelegate>

@property (nonatomic,strong) SQLockView * lockView;
@property (nonatomic,strong) SQWaterwaveView * water;

@end

@implementation SQBenifitsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.water];
    [self.view setBackgroundColor:[UIColor whiteColor]];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
//    self.water.frame = CGRectMake(0, 100, 300, 300);
}

- (SQWaterwaveView *)water {
    
    if (!_water) {
        _water = [SQWaterwaveView new];
        _water.frame =CGRectMake(10, 100, 100, 100);
        _water.waterlevelPercentage = 0.6;
        _water.waterwavePercentage = 0.15;
        _water.waterwaveAccelerate = 0.15;
        _water.waterwaveColor = [UIColor cyanColor];
    }
    return _water;
}

- (SQLockView *)lockView {
    
    if (!_lockView) {
        _lockView = [SQLockView new];
        _lockView.backgroundColor = [UIColor lightGrayColor];
        _lockView.normalImage = [UIImage imageNamed:@"gesture_node_normal"];
        _lockView.highlightImage = [UIImage imageNamed:@"gesture_node_highlighted"];
        _lockView.pathColor = [UIColor redColor];
        _lockView.delegate = self;
    }
    return _lockView;
}

- (void)lockView:(SQLockView *)lockView didFinishPath:(NSString *)path {
    NSLog(@"path -- %@",path);
}










#if 0

- (SQPaintView *)paintView {
    
    if (!_paintView) {
        _paintView = [SQPaintView new];
        _paintView.backgroundColor = [UIColor whiteColor];
        _paintView.lineColor = [UIColor greenColor];
        _paintView.lineWidth = 3;
    }
    return _paintView;
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.paintView.frame = self.view.bounds;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:self.paintView];
}

#endif

@end
