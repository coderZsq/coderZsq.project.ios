//
//  LoopView.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 16/2/4.
//  Copyright © 2016年 Castiel. All rights reserved.
//

#import "LoopView.h"

@implementation LoopView

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGContextMoveToPoint(ctx, 20, 20);
    
    CGContextAddArc(ctx, 30, 30, 10, SQAngle(0), SQAngle(360), YES);
    
    [[UIColor redColor]set];
    
    CGContextStrokePath(ctx);
    
}

@end
