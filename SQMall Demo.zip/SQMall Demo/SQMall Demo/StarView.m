//
//  StarView.m
//
//  Code generated using QuartzCode 1.21 on 15/12/30.
//  www.quartzcodeapp.com
//

#import "StarView.h"
#import "QCMethod.h"


@interface StarView ()

@property (nonatomic, strong) CAShapeLayer *star;

@end

@implementation StarView

- (instancetype)initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	if (self) {
		[self setupLayers];
	}
	return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
	self = [super initWithCoder:coder];
	if (self) {
		[self setupLayers];
	}
	return self;
}


- (void)setupLayers{
	CAShapeLayer * path = [CAShapeLayer layer];
	path.frame       = CGRectMake(15.49, 5.52, 69.71, 83.85);
	path.fillColor   = nil;
	path.strokeColor = [UIColor blackColor].CGColor;
	path.path        = [self pathPath].CGPath;
	[self.layer addSublayer:path];
	
	CAShapeLayer * star = [CAShapeLayer layer];
	star.frame       = CGRectMake(7.94, 27.58, 14.1, 13.23);
	star.fillColor   = [UIColor colorWithRed:0.922 green: 0.922 blue:0.922 alpha:1].CGColor;
	star.strokeColor = [UIColor colorWithRed:0.329 green: 0.329 blue:0.329 alpha:1].CGColor;
	star.path        = [self starPath].CGPath;
	[self.layer addSublayer:star];
	_star = star;
}


- (IBAction)startAllAnimations:(id)sender{
	[self.star addAnimation:[self starAnimation] forKey:@"starAnimation"];
}

- (CAKeyframeAnimation*)starAnimation{
	CAKeyframeAnimation * positionAnim = [CAKeyframeAnimation animationWithKeyPath:@"position"];
	positionAnim.path                  = [QCMethod offsetPath:[self pathPath] by:CGPointMake(7.94, 27.58)].CGPath;
	positionAnim.duration              = 2.32;
	positionAnim.timingFunction        = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
	positionAnim.repeatCount           = INFINITY;
	positionAnim.fillMode = kCAFillModeForwards;
	positionAnim.removedOnCompletion = NO;
	
	return positionAnim;
}

#pragma mark - Bezier Path

- (UIBezierPath*)pathPath{
	UIBezierPath *pathPath = [UIBezierPath bezierPath];
	[pathPath moveToPoint:CGPointMake(0, 28.881)];
	[pathPath addCurveToPoint:CGPointMake(69.714, 28.695) controlPoint1:CGPointMake(0.065, 29.122) controlPoint2:CGPointMake(69.714, 28.695)];
	[pathPath addLineToPoint:CGPointMake(11.493, 83.118)];
	[pathPath addLineToPoint:CGPointMake(33.434, 0)];
	[pathPath addLineToPoint:CGPointMake(63.273, 83.852)];
	[pathPath addCurveToPoint:CGPointMake(0, 28.881) controlPoint1:CGPointMake(63.273, 83.852) controlPoint2:CGPointMake(-0.064, 28.64)];
	
	return pathPath;
}

- (UIBezierPath*)starPath{
	UIBezierPath *starPath = [UIBezierPath bezierPath];
	[starPath moveToPoint:CGPointMake(4.128, 3.287)];
	[starPath addCurveToPoint:CGPointMake(2.343, 8.633) controlPoint1:CGPointMake(0.899, 3.744) controlPoint2:CGPointMake(-2.33, 4.201)];
	[starPath addCurveToPoint:CGPointMake(7.016, 11.936) controlPoint1:CGPointMake(1.792, 11.762) controlPoint2:CGPointMake(1.24, 14.891)];
	[starPath addCurveToPoint:CGPointMake(11.689, 8.633) controlPoint1:CGPointMake(9.904, 13.414) controlPoint2:CGPointMake(12.792, 14.891)];
	[starPath addCurveToPoint:CGPointMake(9.904, 3.287) controlPoint1:CGPointMake(14.026, 6.417) controlPoint2:CGPointMake(16.362, 4.201)];
	[starPath addCurveToPoint:CGPointMake(4.128, 3.287) controlPoint1:CGPointMake(8.46, 0.44) controlPoint2:CGPointMake(7.016, -2.407)];
	[starPath closePath];
	[starPath moveToPoint:CGPointMake(4.128, 3.287)];
	
	return starPath;
}

@end