//
//  HuaRunViewController.m
//  SQMall Demo
//
//  Created by 双泉 朱 on 16/1/15.
//  Copyright © 2016年 Castiel. All rights reserved.
//

#import "HuaRunViewController.h"
#import "HuaRunCell.h"

@interface HuaRunViewController ()

@end

@implementation HuaRunViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 20;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return [HuaRunCell cellWithTableView:tableView];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}


@end
